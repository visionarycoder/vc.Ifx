﻿using Access.Numbers.Contract;
using Access.Numbers.Orm;
using Access.Numbers.Service;
using Access.Rules.Contract;
using Access.Rules.Orm;
using Access.Rules.Service;

using Client.Content.CliApp;

using Engine.Calculating.Contract;
using Engine.Calculating.Service;
using Engine.Validating.Contract;
using Engine.Validating.Service;

using Manager.Content.Contract;
using Manager.Content.Service;

using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
#pragma warning disable CA1848

var host = Host
    .CreateDefaultBuilder(args: args)
    .ConfigureServices(configureDelegate: (context, services) =>
    {
        // Add logging
        services.AddLogging();

        // Add DbContext options
        var numbersConnectionString = context.Configuration.GetConnectionString(name: "NumbersDB") ?? "Data Source=NumbersDB";
        var numbersSqliteConnectionString = new SqliteConnectionStringBuilder(connectionString: numbersConnectionString) { Mode = SqliteOpenMode.Memory, Cache = SqliteCacheMode.Shared }.ToString();
        var numbersOptions = new DbContextOptionsBuilder<NumbersContext>().UseSqlite(connectionString: numbersSqliteConnectionString).Options;
        services.AddSingleton(implementationInstance: numbersOptions);
        services.AddDbContext<NumbersContext>();

        var rulesConnectionString = context.Configuration.GetConnectionString(name: "RulesDB") ?? "Data Source=RulesDB";
        var rulesSqliteConnectionString = new SqliteConnectionStringBuilder(connectionString: rulesConnectionString) { Mode = SqliteOpenMode.Memory, Cache = SqliteCacheMode.Shared }.ToString();
        var rulesOptions = new DbContextOptionsBuilder<RulesContext>().UseSqlite(connectionString: rulesSqliteConnectionString).Options;
        services.AddSingleton(implementationInstance: rulesOptions);
        services.AddDbContext<RulesContext>();

        // Add services
        services.AddScoped<INumbersAccess, NumbersAccess>();
        services.AddScoped<IRulesAccess, RulesAccess>();
        services.AddScoped<ICalculatingEngine, CalculatingEngine>();
        services.AddScoped<IValidatingEngine, ValidatingEngine>();
        services.AddScoped<IContentManager, ContentManager>();
        services.AddScoped<CliClient>();

    })
    .Build();

// Resolve the services and run the application
using var scope = host.Services.CreateScope();
var services = scope.ServiceProvider;

try
{
    var cliClient = services.GetRequiredService<CliClient>();
    await cliClient.RunAsync();
}
catch (Exception ex)
{
    var logger = services.GetRequiredService<ILogger<Program>>();
    logger.LogError(exception: ex, message: "An error occurred while running the application.");
}

await host.RunAsync();
