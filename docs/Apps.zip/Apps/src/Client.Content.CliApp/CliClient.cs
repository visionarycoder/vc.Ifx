﻿using Ifx.Cli;
using Manager.Content.Contract;

namespace Client.Content.CliApp
{
    internal class CliClient(IContentManager contentManager)
    {

        public async Task RunAsync()
        {

            var cancellationToken = CancellationToken.None;

            await DisplayLargestStoredValuesAsync(cancellationToken);
            
            var options = new[]
            {
                    "Get Factorial Number",
                    "Get Factorial Number Sequence",
                    "Get Fibonacci Number",
                    "Get Fibonacci Number Sequence",
                    "Get Perfect Number",
                    "Get Perfect Number Sequence",
                    "Get Prime Number",
                    "Get Prime Number Sequence",
                    "Get Square Number",
                    "Get Square Number Sequence",
                    "Get Triangular Number",
                    "Get Triangular Number Sequence"
                };

            while (true)
            {

                var choice = ConsoleHelper.PromptForMenuSelection(options);
                if (choice == 0)
                {
                    break;
                }

                var position = ConsoleHelper.PromptForInt("Enter position: ", "Invalid position. Please enter a valid number.");

                switch (choice)
                {
                    case 1:
                        var factorialNumber = await contentManager.GetFactorialNumberAsync(position, cancellationToken);
                        Console.WriteLine(factorialNumber != null ? $"Factorial Number: {factorialNumber.Value}" : "Not found");
                        break;
                    case 2:
                        var factorialSequence = await contentManager.GetFactorialNumberSequenceAsync(position, cancellationToken);
                        Console.WriteLine("Factorial Number Sequence: " + string.Join(", ", factorialSequence));
                        break;
                    case 3:
                        var fibonacciNumber = await contentManager.GetFibonacciNumberAsync(position, cancellationToken);
                        Console.WriteLine(fibonacciNumber != null ? $"Fibonacci Number: {fibonacciNumber.Value}" : "Not found");
                        break;
                    case 4:
                        var fibonacciSequence = await contentManager.GetFibonacciNumberSequenceAsync(position, cancellationToken);
                        Console.WriteLine("Fibonacci Number Sequence: " + string.Join(", ", fibonacciSequence));
                        break;
                    case 5:
                        var perfectNumber = await contentManager.GetPerfectNumberAsync(position, cancellationToken);
                        Console.WriteLine(perfectNumber != null ? $"Perfect Number: {perfectNumber.Value}" : "Not found");
                        break;
                    case 6:
                        var perfectSequence = await contentManager.GetPerfectNumberSequenceAsync(position, cancellationToken);
                        Console.WriteLine("Perfect Number Sequence: " + string.Join(", ", perfectSequence));
                        break;
                    case 7:
                        var primeNumber = await contentManager.GetPrimeNumberAsync(position, cancellationToken);
                        Console.WriteLine(primeNumber != null ? $"Prime Number: {primeNumber.Value}" : "Not found");
                        break;
                    case 8:
                        var primeSequence = await contentManager.GetPrimeNumberSequenceAsync(position, cancellationToken);
                        Console.WriteLine("Prime Number Sequence: " + string.Join(", ", primeSequence));
                        break;
                    case 9:
                        var squareNumber = await contentManager.GetSquareNumberAsync(position, cancellationToken);
                        Console.WriteLine(squareNumber != null ? $"Square Number: {squareNumber.Value}" : "Not found");
                        break;
                    case 10:
                        var squareSequence = await contentManager.GetSquareNumberSequenceAsync(position, cancellationToken);
                        Console.WriteLine("Square Number Sequence: " + string.Join(", ", squareSequence));
                        break;
                    case 11:
                        var triangularNumber = await contentManager.GetTriangularNumberAsync(position, cancellationToken);
                        Console.WriteLine(triangularNumber != null ? $"Triangular Number: {triangularNumber.Value}" : "Not found");
                        break;
                    case 12:
                        var triangularSequence = await contentManager.GetTriangularNumberSequenceAsync(position, cancellationToken);
                        Console.WriteLine("Triangular Number Sequence: " + string.Join(", ", triangularSequence));
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please select a valid option.");
                        break;
                }

            }

        }

        private async Task DisplayLargestStoredValuesAsync(CancellationToken cancellationToken = default)
        {

            var factorialNumbers = await contentManager.GetFactorialNumberSequenceAsync(int.MaxValue, cancellationToken);
            var largestFactorial = factorialNumbers.OrderByDescending(n => n.Value).FirstOrDefault();
            Console.WriteLine(largestFactorial != null ? $"Largest Factorial Number: {largestFactorial.Value}" : "No factorial numbers found");

            var fibonacciNumbers = await contentManager.GetFibonacciNumberSequenceAsync(int.MaxValue, cancellationToken);
            var largestFibonacci = fibonacciNumbers.OrderByDescending(n => n.Value).FirstOrDefault();
            Console.WriteLine(largestFibonacci != null ? $"Largest Fibonacci Number: {largestFibonacci.Value}" : "No fibonacci numbers found");

            var perfectNumbers = await contentManager.GetPerfectNumberSequenceAsync(int.MaxValue, cancellationToken);
            var largestPerfect = perfectNumbers.OrderByDescending(n => n.Value).FirstOrDefault();
            Console.WriteLine(largestPerfect != null ? $"Largest Perfect Number: {largestPerfect.Value}" : "No perfect numbers found");

            var primeNumbers = await contentManager.GetPrimeNumberSequenceAsync(int.MaxValue, cancellationToken);
            var largestPrime = primeNumbers.OrderByDescending(n => n.Value).FirstOrDefault();
            Console.WriteLine(largestPrime != null ? $"Largest Prime Number: {largestPrime.Value}" : "No prime numbers found");

            var squareNumbers = await contentManager.GetSquareNumberSequenceAsync(int.MaxValue, cancellationToken);
            var largestSquare = squareNumbers.OrderByDescending(n => n.Value).FirstOrDefault();
            Console.WriteLine(largestSquare != null ? $"Largest Square Number: {largestSquare.Value}" : "No square numbers found");

            var triangularNumbers = await contentManager.GetTriangularNumberSequenceAsync(int.MaxValue, cancellationToken);
            var largestTriangular = triangularNumbers.OrderByDescending(n => n.Value).FirstOrDefault();
            Console.WriteLine(largestTriangular != null ? $"Largest Triangular Number: {largestTriangular.Value}" : "No triangular numbers found");

        }

    }
}
