﻿namespace Engine.Validating.Service;

public class ValidatingEngine(ILogger<ValidatingEngine> logger, IRulesAccess rulesAccess) : ServiceBase<ValidatingEngine>(logger), IValidatingEngine
{
    private const string FACTORIAL_WORKFLOW = "FactorialNumberInputValidation";
    private const string FIBONACCI_WORKFLOW = "FibonacciNumberInputValidation";
    private const string PERFECT_WORKFLOW = "PerfectNumberInputValidation";
    private const string PRIME_WORKFLOW = "PrimeNumberInputValidation";
    private const string SQUARE_WORKFLOW = "SquareNumberInputValidation";
    private const string TRIANGULAR_WORKFLOW = "TriangularNumberInputValidation";

    public async Task<ValidateResponse> ValidateFactorialNumberInputAsync(ValidateRequest request)
    {
        request.WorkflowName = FACTORIAL_WORKFLOW;
        return await ValidateInput(request);
    }

    public async Task<ValidateResponse> ValidateFactorialNumberSequenceInputAsync(ValidateRequest request)
    {
        request.WorkflowName = FACTORIAL_WORKFLOW;
        return await ValidateInput(request);
    }

    public async Task<ValidateResponse> ValidateFibonacciNumberInputAsync(ValidateRequest request)
    {
        request.WorkflowName = FIBONACCI_WORKFLOW;
        return await ValidateInput(request);
    }

    public async Task<ValidateResponse> ValidateFibonacciNumberSequenceInputAsync(ValidateRequest request)
    {
        request.WorkflowName = FIBONACCI_WORKFLOW;
        return await ValidateInput(request);
    }

    public async Task<ValidateResponse> ValidatePerfectNumberInputAsync(ValidateRequest request)
    {
        request.WorkflowName = PERFECT_WORKFLOW;
        return await ValidateInput(request);
    }

    public async Task<ValidateResponse> ValidatePerfectNumberSequenceInputAsync(ValidateRequest request)
    {
        request.WorkflowName = PERFECT_WORKFLOW;
        return await ValidateInput(request);
    }

    public async Task<ValidateResponse> ValidatePrimeNumberInputAsync(ValidateRequest request)
    {
        request.WorkflowName = PRIME_WORKFLOW;
        return await ValidateInput(request);
    }

    public async Task<ValidateResponse> ValidatePrimeNumberSequenceInputAsync(ValidateRequest request)
    {
        request.WorkflowName = PRIME_WORKFLOW;
        return await ValidateInput(request);
    }

    public async Task<ValidateResponse> ValidateSquareNumberInputAsync(ValidateRequest request)
    {
        request.WorkflowName = SQUARE_WORKFLOW;
        return await ValidateInput(request);
    }

    public async Task<ValidateResponse> ValidateSquareNumberSequenceInputAsync(ValidateRequest request)
    {
        request.WorkflowName = SQUARE_WORKFLOW;
        return await ValidateInput(request);
    }

    public async Task<ValidateResponse> ValidateTriangularNumberInputAsync(ValidateRequest request)
    {
        request.WorkflowName = TRIANGULAR_WORKFLOW;
        return await ValidateInput(request);
    }
    public async Task<ValidateResponse> ValidateTriangularNumberSequenceInputAsync(ValidateRequest request)
    {
        request.WorkflowName = TRIANGULAR_WORKFLOW;
        return await ValidateInput(request);
    }

    private async Task<ValidateResponse> ValidateInput(ValidateRequest request)
    {

        var response = await ServiceMessageFactory.CreateFromAsync<ValidateResponse>(request);

        // ToDo: Get workflow from accessor
        var json = await rulesAccess.GetWorkflowAsync(request.WorkflowName).ConfigureAwait(false);
        var workflow = RulesEngineHelper.ConvertToWorkflow(json);
        var rulesEngine = new RulesEngine.RulesEngine([workflow], new ReSettings { IsExpressionCaseSensitive = true });
        var result = await rulesEngine.ExecuteAllRulesAsync(request.WorkflowName, request.Value) ?? [];
        if (result.All(r => r.IsSuccess))
        {
            response.IsSuccess = true;
            return response;
        }

        var errorMessages = result
            .Where(i => string.IsNullOrEmpty(i.ExceptionMessage))
            .Select(i => new ErrorMessage { Message = i.ExceptionMessage })
            .ToList();
        response.ErrorMessages.AddRange(errorMessages);
        return response;

    }
    
}