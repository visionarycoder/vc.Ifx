﻿using Access.Rules.Orm.Models;
using Microsoft.EntityFrameworkCore;

namespace Access.Rules.Orm;

public class RulesContext(DbContextOptions<RulesContext> options) : DbContext(options)
{

    public DbSet<WorkflowEntry> WorkflowEntries { get; init; } = null!;

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);
        optionsBuilder.EnableThreadSafetyChecks();
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {


        modelBuilder.Entity<WorkflowEntry>().ToTable(nameof(WorkflowEntries));
        modelBuilder.Entity<WorkflowEntry>().Property(i => i.Id).ValueGeneratedOnAdd();
        modelBuilder.Entity<WorkflowEntry>().Property(i => i.WorkflowName).IsRequired();
        modelBuilder.Entity<WorkflowEntry>().Property(i => i.Json).IsRequired();

        modelBuilder.Entity<WorkflowEntry>().HasKey(i => i.Id);
        modelBuilder.Entity<WorkflowEntry>().HasIndex(i => i.WorkflowName).IsUnique();

        modelBuilder.Entity<WorkflowEntry>().HasData(
            new WorkflowEntry { Id = 1, WorkflowName = "FactorialNumberInputValidation", Json = GlobalConstants.FACTORIAL_NUMBER_WORKFLOW },
            new WorkflowEntry { Id = 2, WorkflowName = "FibonacciNumberInputValidation", Json = GlobalConstants.FIBONACCI_NUMBER_WORKFLOW },
            new WorkflowEntry { Id = 3, WorkflowName = "PerfectNumberInputValidation", Json = GlobalConstants.PERFECT_NUMBER_WORKFLOW },
            new WorkflowEntry { Id = 4, WorkflowName = "PrimeNumberInputValidation", Json = GlobalConstants.PRIME_NUMBER_WORKFLOW },
            new WorkflowEntry { Id = 5, WorkflowName = "SquareNumberInputValidation", Json = GlobalConstants.SQUARE_NUMBER_WORKFLOW },
            new WorkflowEntry { Id = 6, WorkflowName = "TriangularNumberInputValidation", Json = GlobalConstants.TRIANGULAR_NUMBER_WORKFLOW }
        );

        base.OnModelCreating(modelBuilder);

    }

}