﻿using Ifx.Data;

namespace Access.Rules.Orm.Models;

public record WorkflowEntry : Entity
{
    public string WorkflowName { get; set; } = null!;
    public string Json { get; set; } = null!;
}