﻿#pragma warning disable CA1707
namespace Access.Rules.Orm;

public static class GlobalConstants
{
    
    public const string FACTORIAL_NUMBER_WORKFLOW = """{"WorkflowName":"FactorialNumberInputValidation","Rules":[{"RuleName":"ValidateFactorialInput","SuccessEvent":"Valid Factorial Input","ErrorMessage":"Input must be a non-negative integer.","ErrorType":"Error","RuleExpressionType":"LambdaExpression","Expression":"input >= 0"}]}""";
    public const string FIBONACCI_NUMBER_WORKFLOW = """{"WorkflowName":"FibonacciNumberInputValidation","Rules":[{"RuleName":"ValidateFibonacciInput","SuccessEvent":"Valid Fibonacci Input","ErrorMessage":"Input must be a non-negative integer.","ErrorType":"Error","RuleExpressionType":"LambdaExpression","Expression":"input >= 0"}]}""";
    public const string PERFECT_NUMBER_WORKFLOW = """{"WorkflowName":"PerfectNumberInputValidation","Rules":[{"RuleName":"ValidatePerfectInput","SuccessEvent":"Valid Perfect Input","ErrorMessage":"Input must be a non-negative integer greater than 1.","ErrorType":"Error","RuleExpressionType":"LambdaExpression","Expression":"input > 1"}]}""";
    public const string PRIME_NUMBER_WORKFLOW = """{"WorkflowName":"PrimeNumberInputValidation","Rules":[{"RuleName":"ValidatePrimeInput","SuccessEvent":"Valid Prime Input","ErrorMessage":"Input must be a non-negative integer greater than 1.","ErrorType":"Error","RuleExpressionType":"LambdaExpression","Expression":"input > 1"}]}""";
    public const string SQUARE_NUMBER_WORKFLOW = """{"WorkflowName":"SquareNumberInputValidation","Rules":[{"RuleName":"ValidateSquareInput","SuccessEvent":"Valid Square Input","ErrorMessage":"Input must be a non-negative integer.","ErrorType":"Error","RuleExpressionType":"LambdaExpression","Expression":"input >= 0"}]}""";
    public const string TRIANGULAR_NUMBER_WORKFLOW = """{"WorkflowName":"TriangularNumberInputValidation","Rules":[{"RuleName":"ValidateTriangularInput","SuccessEvent":"Valid Triangular Input","ErrorMessage":"Input must be a non-negative integer.","ErrorType":"Error","RuleExpressionType":"LambdaExpression","Expression":"input >= 0"}]}""";

}