﻿namespace Engine.Validating.Contract;

public record ValidateResponse : ServiceMessageResponse
{
    
    public long Value { get; set; }

}