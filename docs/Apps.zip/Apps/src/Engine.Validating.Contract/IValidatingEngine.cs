﻿namespace Engine.Validating.Contract;

public interface IValidatingEngine
{

    Task<ValidateResponse> ValidateFactorialNumberInputAsync(ValidateRequest request);
    Task<ValidateResponse> ValidateFactorialNumberSequenceInputAsync(ValidateRequest request);
    Task<ValidateResponse> ValidateFibonacciNumberInputAsync(ValidateRequest request);
    Task<ValidateResponse> ValidateFibonacciNumberSequenceInputAsync(ValidateRequest request);
    Task<ValidateResponse> ValidatePerfectNumberInputAsync(ValidateRequest request);
    Task<ValidateResponse> ValidatePerfectNumberSequenceInputAsync(ValidateRequest request);
    Task<ValidateResponse> ValidatePrimeNumberInputAsync(ValidateRequest request);
    Task<ValidateResponse> ValidatePrimeNumberSequenceInputAsync(ValidateRequest request);
    Task<ValidateResponse> ValidateSquareNumberInputAsync(ValidateRequest request);
    Task<ValidateResponse> ValidateSquareNumberSequenceInputAsync(ValidateRequest request);
    Task<ValidateResponse> ValidateTriangularNumberInputAsync(ValidateRequest request);
    Task<ValidateResponse> ValidateTriangularNumberSequenceInputAsync(ValidateRequest request);

}