﻿#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
namespace Engine.Validating.Contract;

public record ValidateRequest : ServiceMessageRequest
{
    public string WorkflowName { get; set; }
    public int Value { get; set; }
}