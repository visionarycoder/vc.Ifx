using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace Ifx.Data.Extensions;

public static class ServiceCollectionExtensions
{

    public static DbContextOptions<TDbContext> GenerateSQLiteOptions<TDbContext>(string sqlConnectionString) where TDbContext : DbContext
    {
        var options = new DbContextOptionsBuilder<TDbContext>().UseSqlite(sqlConnectionString).Options;
        return options;
    }

    public static string GenerateSqliteConnectionString(string connectionString, SqliteOpenMode openMode = SqliteOpenMode.Memory, SqliteCacheMode cacheMode = SqliteCacheMode.Shared)
    {
        var sqliteConnectionString = new SqliteConnectionStringBuilder(connectionString)
        {
            Mode = openMode,
            Cache = cacheMode,
        }.ToString();
        return sqliteConnectionString;
    }

}