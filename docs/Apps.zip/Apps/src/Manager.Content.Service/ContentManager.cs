﻿using Access.Numbers.Contract;
using Engine.Calculating.Contract;
using Engine.Validating.Contract;
using Ifx.Base;
using Manager.Content.Contract;
using Manager.Content.Contract.Models;
using Manager.Content.Service.Helpers;
using Microsoft.Extensions.Logging;
using Util.Messaging;

namespace Manager.Content.Service;

public class ContentManager(ILogger<ContentManager> logger, ICalculatingEngine calculatingEngine, IValidatingEngine validatingEngine, INumbersAccess numbersAccess, IMapper? mapper = null) : ServiceBase<ContentManager>(logger), IContentManager
{

    private readonly IMapper mapper = mapper ?? new MapperConfiguration(cfg => cfg.AddProfile<MappingProfile>()).CreateMapper();

    public async Task<FactorialNumber?> GetFactorialNumberAsync(int position, CancellationToken cancellationToken = default)
    {

        var validationRequest = await ServiceMessageFactory.CreateAsync<ValidateRequest>();
        validationRequest.Value = position;
        var validationResponse = await validatingEngine.ValidateFactorialNumberInputAsync(validationRequest);
        if (validationResponse.HasErrors)
        {
            return null;
        }

        var entry = await calculatingEngine.CalculateFactorialNumberAsync(position, cancellationToken);
        return entry is null
            ? null
            : mapper.Map<FactorialNumber>(entry);

    }

    public async Task<IEnumerable<FactorialNumber>> GetFactorialNumberSequenceAsync(int position, CancellationToken cancellationToken = default)
    {

        var validationRequest = await ServiceMessageFactory.CreateAsync<ValidateRequest>();
        validationRequest.Value = position;
        var validationResponse = await validatingEngine.ValidateFactorialNumberInputAsync(validationRequest);
        if (validationResponse.HasErrors)
        {
            return new List<FactorialNumber>();
        }

        var entries = await calculatingEngine.CalculateFactorialNumberSequenceAsync(position, cancellationToken);
        return entries
            .Select(i => mapper.Map<FactorialNumber>(i))
            .ToList();

    }

    public async Task<FibonacciNumber?> GetFibonacciNumberAsync(int position, CancellationToken cancellationToken)
    {

        var validationRequest = await ServiceMessageFactory.CreateAsync<ValidateRequest>();
        validationRequest.Value = position;
        var validationResponse = await validatingEngine.ValidateFibonacciNumberInputAsync(validationRequest);
        if (validationResponse.HasErrors)
        {
            return null;
        }

        var entry = await calculatingEngine.CalculateFibonacciNumberAsync(position, cancellationToken);
        return entry is null
            ? null
            : mapper.Map<FibonacciNumber>(entry);

    }

    public async Task<IEnumerable<FibonacciNumber>> GetFibonacciNumberSequenceAsync(int position, CancellationToken cancellationToken = default)
    {
        return await Task.FromResult(new List<FibonacciNumber>());
    }

    public async Task<PerfectNumber?> GetPerfectNumberAsync(int position, CancellationToken cancellationToken)
    {
        var validationRequest = await ServiceMessageFactory.CreateAsync<ValidateRequest>();
        validationRequest.Value = position;
        var validationResponse = await validatingEngine.ValidatePerfectNumberInputAsync(validationRequest);
        if (validationResponse.HasErrors)
        {
            return null;
        }

        var entry = await calculatingEngine.CalculatePerfectNumberAsync(position, cancellationToken);
        return entry is null
            ? null
            : mapper.Map<PerfectNumber>(entry);
    }

    public async Task<IEnumerable<PerfectNumber>> GetPerfectNumberSequenceAsync(int position, CancellationToken cancellationToken = default)
    {
        return await Task.FromResult(new List<PerfectNumber>());
    }

    public async Task<PrimeNumber?> GetPrimeNumberAsync(int position, CancellationToken cancellationToken)
    {
        var validationRequest = await ServiceMessageFactory.CreateAsync<ValidateRequest>();
        validationRequest.Value = position;
        var validationResponse = await validatingEngine.ValidatePrimeNumberInputAsync(validationRequest);
        if (validationResponse.HasErrors)
        {
            return null;
        }

        var entry = await calculatingEngine.CalculatePrimeNumberAsync(position, cancellationToken);
        return entry is null
            ? null
            : mapper.Map<PrimeNumber>(entry);
    }

    public async Task<IEnumerable<PrimeNumber>> GetPrimeNumberSequenceAsync(int position, CancellationToken cancellationToken = default)
    {
        return await Task.FromResult(new List<PrimeNumber>());
    }

    public async Task<SquareNumber?> GetSquareNumberAsync(int position, CancellationToken cancellationToken)
    {
        var validationRequest = await ServiceMessageFactory.CreateAsync<ValidateRequest>();
        validationRequest.Value = position;
        var validationResponse = await validatingEngine.ValidateSquareNumberInputAsync(validationRequest);
        if (validationResponse.HasErrors)
        {
            return null;
        }

        var entry = await calculatingEngine.CalculateSquareNumberAsync(position, cancellationToken);
        return entry is null
            ? null
            : mapper.Map<SquareNumber>(entry);
    }

    public async Task<IEnumerable<SquareNumber>> GetSquareNumberSequenceAsync(int position, CancellationToken cancellationToken = default)
    {
        return await Task.FromResult(new List<SquareNumber>());
    }

    public async Task<TriangularNumber?> GetTriangularNumberAsync(int position, CancellationToken cancellationToken = default)
    {
        var validationRequest = await ServiceMessageFactory.CreateAsync<ValidateRequest>();
        validationRequest.Value = position;
        var validationResponse = await validatingEngine.ValidateTriangularNumberInputAsync(validationRequest);
        if (validationResponse.HasErrors)
        {
            return null;
        }

        var entry = await calculatingEngine.CalculateTriangularNumberAsync(position, cancellationToken);
        return entry is null
            ? null
            : mapper.Map<TriangularNumber>(entry);
    }

    public async Task<IEnumerable<TriangularNumber>> GetTriangularNumberSequenceAsync(int position, CancellationToken cancellationToken = default)
    {
        return await Task.FromResult(new List<TriangularNumber>());
    }

}