﻿using Access.Numbers.Contract.Models;
using Ifx;

namespace Access.Numbers.Contract;

public interface INumbersAccess
{

    #region FactorialNumber
    Task<ICollection<FactorialNumber>> FindFactorialNumbersAsync(Filter<FactorialNumber> filter, CancellationToken cancellationToken = default);
    Task<FactorialNumber?> AddFactorialNumberAsync(FactorialNumber number, CancellationToken cancellationToken = default);
    Task<FactorialNumber?> FindLargestFactorialNumberAsync(CancellationToken cancellationToken = default);
    #endregion FactorialNumber

    #region FibonacciNumber
    Task<ICollection<FibonacciNumber>> FindFibonacciNumbersAsync(Filter<FibonacciNumber> filter, CancellationToken cancellationToken = default);
    Task<FibonacciNumber?> AddFibonacciNumberAsync(FibonacciNumber number, CancellationToken cancellationToken = default);
    Task<FibonacciNumber?> FindLargestFibonacciNumberAsync(CancellationToken cancellationToken = default);
    #endregion FibonacciNumber

    #region PerfectNumber
    Task<ICollection<PerfectNumber>> FindPerfectNumbersAsync(Filter<PerfectNumber> filter, CancellationToken cancellationToken = default);
    Task<PerfectNumber?> AddPerfectNumberAsync(PerfectNumber number, CancellationToken cancellationToken = default);
    Task<PerfectNumber?> FindLargestPerfectNumberAsync(CancellationToken cancellationToken = default);
    #endregion PerfectNumber

    #region PrimeNumber
    Task<ICollection<PrimeNumber>> FindPrimeNumbersAsync(Filter<PrimeNumber> filter, CancellationToken cancellationToken = default);
    Task<PrimeNumber?> AddPrimeNumberAsync(PrimeNumber number, CancellationToken cancellationToken = default);
    Task<PrimeNumber?> FindLargestPrimeNumberAsync(CancellationToken cancellationToken = default);
    #endregion PrimeNumber

    #region SquareNumber
    Task<ICollection<SquareNumber>> FindSquareNumbersAsync(Filter<SquareNumber> filter, CancellationToken cancellationToken = default);
    Task<SquareNumber?> AddSquareNumberAsync(SquareNumber number, CancellationToken cancellationToken = default);
    Task<SquareNumber?> FindLargestSquareNumberAsync(CancellationToken cancellationToken = default);
    #endregion SquareNumber

    #region TriangularNumber
    Task<ICollection<TriangularNumber>> FindTriangularNumbersAsync(Filter<TriangularNumber> filter, CancellationToken cancellationToken = default);
    Task<TriangularNumber?> AddTriangularNumberAsync(TriangularNumber number, CancellationToken cancellationToken = default);
    Task<TriangularNumber?> FindLargestTriangularNumberAsync(CancellationToken cancellationToken = default);
    #endregion TriangularNumber

}