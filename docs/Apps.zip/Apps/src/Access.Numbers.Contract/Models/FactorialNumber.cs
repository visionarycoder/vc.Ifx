namespace Access.Numbers.Contract.Models;

public class FactorialNumber : NumberBase { }
