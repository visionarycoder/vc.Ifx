namespace Access.Numbers.Contract.Models;

public class TriangularNumber : NumberBase { }
