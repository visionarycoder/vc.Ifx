namespace Access.Numbers.Contract.Models;

public class PerfectNumber : NumberBase { }
