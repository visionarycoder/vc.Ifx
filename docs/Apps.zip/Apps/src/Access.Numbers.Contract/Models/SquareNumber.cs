namespace Access.Numbers.Contract.Models;

public class SquareNumber : NumberBase { }
