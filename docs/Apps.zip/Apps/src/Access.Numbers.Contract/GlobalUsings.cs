// Global using directives

global using Ifx.Base;