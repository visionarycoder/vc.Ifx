namespace Client.Content.WebApi.Models;

public class TriangularNumber 
{
    public int Position { get; set; }
    public long Value { get; set; }
}