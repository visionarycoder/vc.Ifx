namespace Client.Content.WebApi.Models;

public class SquareNumber 
{
    public int Position { get; set; }
    public long Value { get; set; }
}