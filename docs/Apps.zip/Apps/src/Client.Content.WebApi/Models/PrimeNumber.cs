namespace Client.Content.WebApi.Models;

public class PrimeNumber 
{
    public int Position { get; set; }
    public long Value { get; set; }
}