namespace Client.Content.WebApi.Models;

public class FactorialNumber 
{
    public int Position { get; set; }
    public long Value { get; set; }
}