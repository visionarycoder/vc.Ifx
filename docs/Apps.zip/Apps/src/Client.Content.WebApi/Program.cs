using Access.Numbers.Contract;
using Access.Numbers.Orm;
using Access.Numbers.Service;
using Access.Rules.Contract;
using Access.Rules.Orm;
using Access.Rules.Service;

using Engine.Calculating.Contract;
using Engine.Calculating.Service;
using Engine.Validating.Contract;
using Engine.Validating.Service;

using Manager.Content.Contract;
using Manager.Content.Service;

using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
var webApiUrl = builder.Configuration.GetSection("WebApiUrl").Value ?? string.Empty;

builder.Services.AddCors
        (
            options =>
            {
                options.AddDefaultPolicy(policy =>
                        policy
                            .WithOrigins(webApiUrl)
                            .AllowAnyHeader()
                            .AllowAnyMethod()
                    );
            }
        );

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var numbersConnectionString = builder.Configuration.GetConnectionString("NumbersDB") ?? "Data Source=NumbersDB";
var numbersSqliteConnectionString = new SqliteConnectionStringBuilder(numbersConnectionString) { Mode = SqliteOpenMode.Memory, Cache = SqliteCacheMode.Shared }.ToString();
var numbersOptions = new DbContextOptionsBuilder<NumbersContext>().UseSqlite(numbersSqliteConnectionString).Options;
builder.Services.AddSingleton(numbersOptions);
builder.Services.AddDbContext<NumbersContext>();

var rulesConnectionString = builder.Configuration.GetConnectionString("RulesDB") ?? "Data Source=RulesDB";
var rulesSqliteConnectionString = new SqliteConnectionStringBuilder(rulesConnectionString) { Mode = SqliteOpenMode.Memory, Cache = SqliteCacheMode.Shared }.ToString();
var rulesOptions = new DbContextOptionsBuilder<RulesContext>().UseSqlite(rulesSqliteConnectionString).Options;
builder.Services.AddSingleton(rulesOptions);
builder.Services.AddDbContext<RulesContext>();

builder.Services.AddSingleton<INumbersAccess, NumbersAccess>();
builder.Services.AddSingleton<IRulesAccess, RulesAccess>();
builder.Services.AddSingleton<ICalculatingEngine, CalculatingEngine>();
builder.Services.AddSingleton<IValidatingEngine, ValidatingEngine>();
builder.Services.AddSingleton<IContentManager, ContentManager>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();

return;