using Client.Content.WebApi.Models;

using Manager.Content.Contract;

using Microsoft.AspNetCore.Mvc;
namespace Client.Content.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TriangularNumbersController(IContentManager contentManager) : ControllerBase
{

    [HttpGet("{position:int}")]
    public async Task<ActionResult<TriangularNumber>> GetTriangularNumber(int position, CancellationToken cancellationToken)
    {
        var triangularNumber = await contentManager.GetTriangularNumberAsync(position, cancellationToken);
        if (triangularNumber == null)
        {
            return NotFound();
        }
        return Ok(triangularNumber);
    }

    [HttpGet("sequence/{position:int}")]
    public async Task<ActionResult<IEnumerable<TriangularNumber>>> GetTriangularNumberSequence(int position, CancellationToken cancellationToken)
    {
        var sequence = await contentManager.GetTriangularNumberSequenceAsync(position, cancellationToken);
        return Ok(sequence);
    }
}

