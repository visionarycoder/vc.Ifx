using Client.Content.WebApi.Models;

using Manager.Content.Contract;

using Microsoft.AspNetCore.Mvc;

namespace Client.Content.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FibonacciNumbersController(IContentManager contentManager) : ControllerBase
{
    [HttpGet("{position:int}")]
    public async Task<ActionResult<FibonacciNumber>> GetFibonacciNumber(int position, CancellationToken cancellationToken)
    {
        var fibonacciNumber = await contentManager.GetFibonacciNumberAsync(position, cancellationToken);
        if (fibonacciNumber == null)
        {
            return NotFound();
        }
        return Ok(fibonacciNumber);
    }

    [HttpGet("sequence/{position:int}")]
    public async Task<ActionResult<IEnumerable<FibonacciNumber>>> GetFibonacciNumberSequence(int position, CancellationToken cancellationToken)
    {
        var sequence = await contentManager.GetFibonacciNumberSequenceAsync(position, cancellationToken);
        return Ok(sequence);
    }
}
