using Client.Content.WebApi.Models;

using Manager.Content.Contract;

using Microsoft.AspNetCore.Mvc;
namespace Client.Content.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PrimeNumbersController(IContentManager contentManager) : ControllerBase
{
    [HttpGet("{position:int}")]
    public async Task<ActionResult<PrimeNumber>> GetPrimeNumber(int position, CancellationToken cancellationToken)
    {
        var primeNumber = await contentManager.GetPrimeNumberAsync(position, cancellationToken);
        if (primeNumber == null)
        {
            return NotFound();
        }
        return Ok(primeNumber);
    }

    [HttpGet("sequence/{position:int}")]
    public async Task<ActionResult<IEnumerable<PrimeNumber>>> GetPrimeNumberSequence(int position, CancellationToken cancellationToken)
    {
        var sequence = await contentManager.GetPrimeNumberSequenceAsync(position, cancellationToken);
        return Ok(sequence);
    }
}
