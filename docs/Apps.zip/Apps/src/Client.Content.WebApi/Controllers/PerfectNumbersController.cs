using Client.Content.WebApi.Models;

using Manager.Content.Contract;

using Microsoft.AspNetCore.Mvc;

namespace Client.Content.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PerfectNumbersController(IContentManager contentManager) : ControllerBase
{
    [HttpGet("{position:int}")]
    public async Task<ActionResult<PerfectNumber>> GetPerfectNumber(int position, CancellationToken cancellationToken)
    {
        var perfectNumber = await contentManager.GetPerfectNumberAsync(position, cancellationToken);
        if (perfectNumber == null)
        {
            return NotFound();
        }
        return Ok(perfectNumber);
    }

    [HttpGet("sequence/{position:int}")]
    public async Task<ActionResult<IEnumerable<PerfectNumber>>> GetPerfectNumberSequence(int position, CancellationToken cancellationToken)
    {
        var sequence = await contentManager.GetPerfectNumberSequenceAsync(position, cancellationToken);
        return Ok(sequence);
    }
}
