using Client.Content.WebApi.Models;

using Manager.Content.Contract;

using Microsoft.AspNetCore.Mvc;
namespace Client.Content.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SquareNumbersController(IContentManager contentManager) : ControllerBase
{
    [HttpGet("{position:int}")]
    public async Task<ActionResult<SquareNumber>> GetSquareNumber(int position, CancellationToken cancellationToken)
    {
        var squareNumber = await contentManager.GetSquareNumberAsync(position, cancellationToken);
        if (squareNumber == null)
        {
            return NotFound();
        }
        return Ok(squareNumber);
    }

    [HttpGet("sequence/{position:int}")]
    public async Task<ActionResult<IEnumerable<SquareNumber>>> GetSquareNumberSequence(int position, CancellationToken cancellationToken)
    {
        var sequence = await contentManager.GetSquareNumberSequenceAsync(position, cancellationToken);
        return Ok(sequence);
    }
}

