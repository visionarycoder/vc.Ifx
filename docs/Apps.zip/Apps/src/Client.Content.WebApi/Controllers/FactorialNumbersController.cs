using Client.Content.WebApi.Models;
using Manager.Content.Contract;
using Microsoft.AspNetCore.Mvc;

namespace Client.Content.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FactorialNumbersController(IContentManager contentManager) : ControllerBase
{
    [HttpGet("{position:int}")]
    public async Task<ActionResult<FactorialNumber>> GetFactorialNumber(int position, CancellationToken cancellationToken)
    {
        var factorialNumber = await contentManager.GetFactorialNumberAsync(position, cancellationToken);
        if (factorialNumber == null)
        {
            return NotFound();
        }
        return Ok(factorialNumber);
    }

    [HttpGet("sequence/{position:int}")]
    public async Task<ActionResult<IEnumerable<FactorialNumber>>> GetFactorialNumberSequence(int position, CancellationToken cancellationToken)
    {
        var sequence = await contentManager.GetFactorialNumberSequenceAsync(position, cancellationToken);
        return Ok(sequence);
    }
}
