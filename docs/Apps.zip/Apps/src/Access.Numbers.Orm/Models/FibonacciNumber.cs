using Access.Numbers.Orm.Models.Base;

namespace Access.Numbers.Orm.Models;

public record FibonacciNumber : Number
{
}