﻿using Ifx.Data;

namespace Access.Numbers.Orm.Models.Base;

public record Number : Entity
{
    public int Position { get; init; }
    public long Value { get; init; }
}