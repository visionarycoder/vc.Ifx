﻿using Access.Numbers.Orm.Models;
using Microsoft.EntityFrameworkCore;

namespace Access.Numbers.Orm;

public class NumbersContext(DbContextOptions<NumbersContext> options) : DbContext(options)
{

    public DbSet<FibonacciNumber> FibonacciNumbers { get; init; } = null!;
    public DbSet<PerfectNumber> PerfectNumbers { get; init; } = null!;
    public DbSet<PrimeNumber> PrimeNumbers { get; init; } = null!;
    public DbSet<TriangularNumber> TriangularNumbers { get; init; } = null!;
    public DbSet<SquareNumber> SquareNumbers { get; init; } = null!;
    public DbSet<FactorialNumber> FactorialNumbers { get; init; } = null!;

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);
        optionsBuilder.EnableThreadSafetyChecks();
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        ConfigureEntity<FactorialNumber>(modelBuilder, nameof(FactorialNumbers));
        ConfigureEntity<FibonacciNumber>(modelBuilder, nameof(FibonacciNumbers));
        ConfigureEntity<PerfectNumber>(modelBuilder, nameof(PerfectNumbers));
        ConfigureEntity<PrimeNumber>(modelBuilder, nameof(PrimeNumbers));
        ConfigureEntity<TriangularNumber>(modelBuilder, nameof(TriangularNumbers));
        ConfigureEntity<SquareNumber>(modelBuilder, nameof(SquareNumbers));

        base.OnModelCreating(modelBuilder);
    }

    private static void ConfigureEntity<T>(ModelBuilder modelBuilder, string tableName) where T : Models.Base.Number
    {
        modelBuilder.Entity<T>().ToTable(tableName);
        modelBuilder.Entity<T>().HasKey(x => x.Id);
        modelBuilder.Entity<T>().Property(x => x.Id).ValueGeneratedOnAdd();
        modelBuilder.Entity<T>().Property(x => x.Position).IsRequired();
        modelBuilder.Entity<T>().HasIndex(x => x.Position).IsUnique();
        modelBuilder.Entity<T>().Property(x => x.Value).IsRequired();
        modelBuilder.Entity<T>().HasIndex(x => x.Value).IsUnique();
    }

}