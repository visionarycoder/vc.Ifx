﻿using Newtonsoft.Json;
using RulesEngine.Models;

namespace Ifx.Helpers;

public static class RulesEngineHelper
{
    public static Workflow ConvertToWorkflow(string json)
    {
        return JsonConvert.DeserializeObject<Workflow>(json) ?? new Workflow();
    }
}