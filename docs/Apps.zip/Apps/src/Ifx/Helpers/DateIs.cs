﻿namespace Ifx.Helpers;

public enum DateIs
{
    InThePast,
    InTheFuture
}