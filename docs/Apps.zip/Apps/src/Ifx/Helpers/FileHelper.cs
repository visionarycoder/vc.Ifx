﻿
// ReSharper disable MemberCanBePrivate.Global

namespace Ifx.Helpers;

public static class FileHelper
{

    public static string Load(FileInfo fileInfo)
    {
        Contract.Assert(fileInfo != null, nameof(fileInfo) + " != null");
        return File.ReadAllText(fileInfo.FullName);
    }

    public static async Task<string> LoadAsync(FileInfo fileInfo)
    {
        Contract.Assert(fileInfo != null, nameof(fileInfo) + " != null");
        return await File.ReadAllTextAsync(fileInfo.FullName).ConfigureAwait(false);
    }

    public static string Load(string filename)
    {
        var fileInfo = new FileInfo(filename);
        return Load(fileInfo);
    }

    public static async Task<string> LoadAsync(string filename)
    {
        var fileInfo = new FileInfo(filename);
        return await LoadAsync(fileInfo).ConfigureAwait(false);
    }

}