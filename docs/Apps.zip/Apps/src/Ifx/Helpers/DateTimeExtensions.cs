﻿namespace Ifx.Helpers;

public static class DateTimeExtensions
{

    /// <summary>
    /// Shifts the input date to the in
    /// </summary>
    /// <param name="input"></param>
    /// <param name="dayOfWeek"></param>
    /// <param name="dateIs"></param>
    /// <returns></returns>
    public static DateTime ShiftTo(this DateTime input, DayOfWeek dayOfWeek = DayOfWeek.Sunday, DateIs dateIs = DateIs.InThePast)
    {
        
        var offset = (int)dayOfWeek - (int)input.DayOfWeek;
        var output = input.AddDays(offset).Date;
        return output;

    }

    public static DateTime GetDate(this DateTime dateTime, TimeSpan timeSpan, DateIs dateIs = DateIs.InThePast)
    {

        var targetDateTime = dateIs == DateIs.InThePast
            ? DateTime.Now.Subtract(timeSpan)
            : DateTime.Now.Add(timeSpan);
        var targetDate = targetDateTime.Date;
        return targetDate;

    }

}