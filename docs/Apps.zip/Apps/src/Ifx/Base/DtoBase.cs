﻿namespace Ifx.Base;

public abstract class DtoBase
{
    
    public int Id { get; init; }
    public Guid InstanceId { get; } = Guid.NewGuid();

}