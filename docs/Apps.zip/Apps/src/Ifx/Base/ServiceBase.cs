﻿using Microsoft.Extensions.Logging;
// ReSharper disable InconsistentNaming

namespace Ifx.Base;

public abstract class ServiceBase<T>(ILogger<T> logger)
    where T : class
{

    protected internal ILogger<T> logger { get; } = logger;

}