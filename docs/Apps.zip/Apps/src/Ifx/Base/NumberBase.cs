﻿namespace Ifx.Base
{
    public abstract class NumberBase : DtoBase
    {
        public int Position { get; init; }
        public long Value { get; init; }
    }
}
