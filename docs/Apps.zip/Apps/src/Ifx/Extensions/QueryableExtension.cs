﻿using System.Linq.Expressions;

namespace Ifx.Extensions;

public static class QueryableExtension
{

    /// <summary>  
    /// Applies order filtering to the query based on the specified filter.  If no Order By property is specified, the query is returned as is.
    /// </summary>  
    /// <typeparam name="T">The type of the entities in the query.</typeparam>  
    /// <param name="query">The query to apply the order to.</param>
    /// <param name="orderBy"></param>
    /// <param name="orderByDirection"></param>
    /// <param name="thenBy"></param>
    /// <param name="thenByDirection"></param>
    /// <returns>The ordered query.</returns>  
    public static IQueryable<T> ApplyOrdering<T>(this IQueryable<T> query, string? orderBy = null, ListSortDirection orderByDirection = ListSortDirection.Ascending, string? thenBy = null, ListSortDirection thenByDirection = ListSortDirection.Ascending) where T : class
    {

        // Eject if no OrderBy content is specified without looking at ThenBy
        if (string.IsNullOrEmpty(orderBy))
        {
            return query;
        }

        query = query.ApplyOrder(orderBy, orderByDirection == ListSortDirection.Descending ? "OrderByDescending" : "OrderBy");
        if(string.IsNullOrEmpty(thenBy))
        {
            return query;
        }

        query = query.ApplyOrder(thenBy, thenByDirection == ListSortDirection.Descending ? "ThenByDescending" : "ThenBy");
        return query;

    }

    private static IQueryable<T> ApplyOrder<T>(this IQueryable<T> query, string propertyName, string methodName) where T : class
    {
        var parameter = Expression.Parameter(typeof(T), "param");
        var property = Expression.Property(parameter, propertyName);
        var lambda = Expression.Lambda(property, parameter);
        var resultExpression = Expression.Call(typeof(Queryable), methodName, [typeof(T), property.Type], query.Expression, Expression.Quote(lambda));
        return query.Provider.CreateQuery<T>(resultExpression);
    }

    /// <summary>  
    /// Applies pagination filtering to the query based on the specified filter.  
    /// </summary>  
    /// <typeparam name="T">The type of the entities in the query.</typeparam>  
    /// <param name="query">The query to apply the pagination to.</param>
    /// <param name="skip"></param>
    /// <param name="take"></param>
    /// <returns>The paginated query.</returns>  
    public static IQueryable<T> ApplyPagination<T>(this IQueryable<T> query, int? skip, int? take) where T : class
    {

        if (skip >= 0)
        {
            query = query.Skip(skip.Value);
        }

        if (take >= 1)
        {
            query = query.Take(take.Value);
        }
        return query;

    }

}