﻿namespace Ifx.Extensions;

public static class FilterExtension
{
	
	/// <summary>  
	/// Converts a filter of one type to a filter of another type.  
	/// </summary>  
	/// <typeparam name="TIn">The source type of the filter.</typeparam>  
	/// <typeparam name="TOut">The target type of the filter.</typeparam>  
	/// <param name="source">The source filter to convert.</param>  
	/// <returns>The converted filter.</returns>  
	public static Filter<TOut> Convert<TIn, TOut>(this Filter<TIn> source) where TIn : class where TOut : class
	{

		var target = new Filter<TOut>
		{

			IgnoreCase = source.IgnoreCase,

			Skip = source.Skip,
			Take = source.Take,

			OrderBy = source.OrderBy,
			OrderByDirection = source.OrderByDirection,

			ThenBy = source.ThenBy,
			ThenByDirection = source.ThenByDirection

		};
        target.PropertyValues = source.PropertyValues.ToDictionary(kvp => kvp.Key, kvp => kvp.Value);

        return target;

	}
	
}