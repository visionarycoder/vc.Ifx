﻿// ReSharper disable MemberCanBePrivate.Global

global using System.ComponentModel;
global using System.Diagnostics.Contracts;