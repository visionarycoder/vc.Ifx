﻿namespace Ifx;

public enum IgnoreCase
{
    Yes,
    No
}