﻿namespace Ifx;

public class Filter<T> where T : class
{

    private readonly Dictionary<string, object?> propertyValues = new();

    public static Filter<T> EmptyFilter => new();

    // Dictionary to store property names and values
    public IDictionary<string, object?> PropertyValues => propertyValues;

    // Ignore case property
    public IgnoreCase IgnoreCase { get; set; } = IgnoreCase.Yes;

    // Pagination properties
    public int? Skip { get; set; } = 0;
    public int? Take { get; set; } = 50;

    // Ordering properties
    public string? OrderBy { get; set; }
    public ListSortDirection OrderByDirection { get; set; } = ListSortDirection.Ascending;
    public string? ThenBy { get; set; }
    public ListSortDirection ThenByDirection { get; set; } = ListSortDirection.Ascending;

    // Generic empty constructor
    public Filter() { }

    // Constructor to add properties as params
    public Filter(params (string propertyName, object? value)[] properties)
    {
        foreach (var (propertyName, value) in properties)
        {
            AddProperty(propertyName, value);
        }
    }

    // Method to add a property and its value to the dictionary
    // If the property already exists, it will be updated
    public void AddProperty(string propertyName, object? value)
    {
        propertyValues[propertyName] = value;
    }

    public void AddProperty(KeyValuePair<string, object?> property)
    {
        propertyValues[property.Key] = property.Value;
    }

    public void AddRange((string propertyName, object? value)[] nameValuePairs)
    {
        nameValuePairs
            .ToList()
            .ForEach(property => AddProperty(property.propertyName, property.value));
    }

    public void AddRange(KeyValuePair<string, object?>[] keyValuePairs)
    {
        keyValuePairs
            .ToList()
            .ForEach(AddProperty);
    }

}