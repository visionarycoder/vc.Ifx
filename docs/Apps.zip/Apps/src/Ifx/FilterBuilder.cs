﻿namespace Ifx;

public class FilterBuilder<T> where T : class
{

    private readonly Filter<T> filter = new();

    public FilterBuilder<T> SetIgnoreCase(IgnoreCase ignoreCase)
    {
        filter.IgnoreCase = ignoreCase;
        return this;
    }

    public FilterBuilder<T> SetSkip(int? skip)
    {
        filter.Skip = skip;
        return this;
    }

    public FilterBuilder<T> SetTake(int? take)
    {
        filter.Take = take;
        return this;
    }

    public FilterBuilder<T> SetOrderBy(string orderBy)
    {
        filter.OrderBy = orderBy;
        return this;
    }

    public FilterBuilder<T> SetOrderByDirection(ListSortDirection orderByDirection)
    {
        filter.OrderByDirection = orderByDirection;
        return this;
    }

    public FilterBuilder<T> SetThenBy(string thenBy)
    {
        filter.ThenBy = thenBy;
        return this;
    }

    public FilterBuilder<T> SetThenByDirection(ListSortDirection thenByDirection)
    {
        filter.ThenByDirection = thenByDirection;
        return this;
    }

    public FilterBuilder<T> AddFilters(params (string propertyName, object? value)[] filters)
    {
        filter.AddRange(filters);
        return this;
    }

    public FilterBuilder<T> AddFilters(params KeyValuePair<string, object?>[] filters)
    {
        filter.AddRange(filters);
        return this;
    }

    public Filter<T> Build()
    {
        return filter;
    }

}