﻿// ReSharper disable MemberCanBePrivate.Global

global using Azure.Storage.Blobs;
global using Microsoft.Extensions.Logging;