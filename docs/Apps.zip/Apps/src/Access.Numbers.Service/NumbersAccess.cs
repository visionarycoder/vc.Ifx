﻿using System.ComponentModel;
using Access.Numbers.Contract;
using Access.Numbers.Contract.Models;
using Access.Numbers.Orm;
using Access.Numbers.Service.Helpers;
using Ifx;
using Ifx.Base;
using Ifx.Data;
using Ifx.Data.Extensions;
using Ifx.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Access.Numbers.Service;

public class NumbersAccess(ILogger<NumbersAccess> logger, DbContextOptions<NumbersContext> options, IMapper? mapper = null) : ServiceBase<NumbersAccess>(logger), INumbersAccess, IAsyncDisposable, IDisposable
{

    private readonly NumbersContext ctx = new(options);
    private readonly IMapper mapper = mapper ?? new MapperConfiguration(cfg => cfg.AddProfile<MappingProfile>()).CreateMapper();

    #region FactorialNumber
    public Task<ICollection<FactorialNumber>> FindFactorialNumbersAsync(Filter<FactorialNumber> filter, CancellationToken cancellationToken = default)
        => FindAsync<Access.Numbers.Orm.Models.FactorialNumber, FactorialNumber>(filter, cancellationToken);

    public Task<FactorialNumber?> AddFactorialNumberAsync(FactorialNumber number, CancellationToken cancellationToken = default)
        => AddAsync<Access.Numbers.Orm.Models.FactorialNumber, FactorialNumber>(number, cancellationToken);

    public async Task<FactorialNumber?> FindLargestFactorialNumberAsync(CancellationToken cancellationToken = default)
        => await FindLargestValueAsync<Access.Numbers.Orm.Models.FactorialNumber, FactorialNumber>(cancellationToken);
    
    #endregion FactorialNumber

    #region FibonacciNumber
    public Task<ICollection<FibonacciNumber>> FindFibonacciNumbersAsync(Filter<FibonacciNumber> filter, CancellationToken cancellationToken = default)
        => FindAsync<Access.Numbers.Orm.Models.FibonacciNumber, FibonacciNumber>(filter, cancellationToken);

    public Task<FibonacciNumber?> AddFibonacciNumberAsync(FibonacciNumber number, CancellationToken cancellationToken = default)
        => AddAsync<Access.Numbers.Orm.Models.FibonacciNumber, FibonacciNumber>(number, cancellationToken);

    public async Task<FibonacciNumber?> FindLargestFibonacciNumberAsync(CancellationToken cancellationToken = default)
        => await FindLargestValueAsync<Access.Numbers.Orm.Models.FibonacciNumber, FibonacciNumber>(cancellationToken);
    #endregion FibonacciNumber

    #region PerfectNumber
    public Task<ICollection<PerfectNumber>> FindPerfectNumbersAsync(Filter<PerfectNumber> filter, CancellationToken cancellationToken = default)
        => FindAsync<Access.Numbers.Orm.Models.PerfectNumber, PerfectNumber>(filter, cancellationToken);

    public Task<PerfectNumber?> AddPerfectNumberAsync(PerfectNumber number, CancellationToken cancellationToken = default)
        => AddAsync<Access.Numbers.Orm.Models.PerfectNumber, PerfectNumber>(number, cancellationToken);

    public async Task<PerfectNumber?> FindLargestPerfectNumberAsync(CancellationToken cancellationToken = default)
        => await FindLargestValueAsync<Access.Numbers.Orm.Models.PerfectNumber, PerfectNumber>(cancellationToken);
    #endregion PerfectNumber

    #region PrimeNumber
    public Task<ICollection<PrimeNumber>> FindPrimeNumbersAsync(Filter<PrimeNumber> filter, CancellationToken cancellationToken = default)
        => FindAsync<Access.Numbers.Orm.Models.PrimeNumber, PrimeNumber>(filter, cancellationToken);

    public Task<PrimeNumber?> AddPrimeNumberAsync(PrimeNumber number, CancellationToken cancellationToken = default)
        => AddAsync<Access.Numbers.Orm.Models.PrimeNumber, PrimeNumber>(number, cancellationToken);

    public async Task<PrimeNumber?> FindLargestPrimeNumberAsync(CancellationToken cancellationToken = default)
        => await FindLargestValueAsync<Access.Numbers.Orm.Models.PrimeNumber, PrimeNumber>(cancellationToken);
    #endregion PrimeNumber

    #region SquareNumber
    public Task<ICollection<SquareNumber>> FindSquareNumbersAsync(Filter<SquareNumber> filter, CancellationToken cancellationToken = default)
        => FindAsync<Access.Numbers.Orm.Models.SquareNumber, SquareNumber>(filter, cancellationToken);

    public Task<SquareNumber?> AddSquareNumberAsync(SquareNumber number, CancellationToken cancellationToken = default)
        => AddAsync<Access.Numbers.Orm.Models.SquareNumber, SquareNumber>(number, cancellationToken);

    public async Task<SquareNumber?> FindLargestSquareNumberAsync(CancellationToken cancellationToken = default)
        => await FindLargestValueAsync<Access.Numbers.Orm.Models.SquareNumber, SquareNumber>(cancellationToken);
    #endregion SquareNumber

    #region TriangularNumber
    public Task<ICollection<TriangularNumber>> FindTriangularNumbersAsync(Filter<TriangularNumber> filter, CancellationToken cancellationToken = default)
        => FindAsync<Access.Numbers.Orm.Models.TriangularNumber, TriangularNumber>(filter, cancellationToken);

    public Task<TriangularNumber?> AddTriangularNumberAsync(TriangularNumber number, CancellationToken cancellationToken = default)
        => AddAsync<Access.Numbers.Orm.Models.TriangularNumber, TriangularNumber>(number, cancellationToken);

    public async Task<TriangularNumber?> FindLargestTriangularNumberAsync(CancellationToken cancellationToken = default)
        => await FindLargestValueAsync<Access.Numbers.Orm.Models.TriangularNumber, TriangularNumber>(cancellationToken);
    #endregion TriangularNumber

    #region Generics
    private async Task<ICollection<TDto>> FindAsync<TEntity, TDto>(Filter<TDto> filter, CancellationToken cancellationToken) where TEntity : Entity where TDto : DtoBase
    {
        var convertedFilter = filter.Convert<TDto, TEntity>();
        var query = ctx.Set<TEntity>().AsQueryable();
        query = query.ApplyFilter(convertedFilter);
        var entities = await query.ToListAsync(cancellationToken);
        return mapper.Map<ICollection<TDto>>(entities);
    }

    private async Task<TDto?> AddAsync<TEntity, TDto>(TDto dto, CancellationToken cancellationToken) where TEntity : Entity where TDto : DtoBase
    {
        var entity = mapper.Map<TEntity>(dto);
        ctx.Set<TEntity>().Add(entity);
        await ctx.SaveChangesAsync(cancellationToken);
        return mapper.Map<TDto>(entity);
    }

    private async Task<TDto?> FindLargestValueAsync<TEntity, TDto>(CancellationToken cancellationToken) where TEntity : Entity where TDto : DtoBase
    {
        var filter = new Filter<TEntity>
        {
            Skip = null,
            Take = 1,
            OrderBy = "Position",
             = ListSortDirection.Descending
        };
        var query = ctx.Set<TEntity>().AsQueryable();
        query = query.ApplyFilter(filter);
        var entity = (await query.ToListAsync(cancellationToken)).FirstOrDefault();
        return mapper.Map<TDto>(entity);
    }
    #endregion Generics

    #region IDisposable
    private void Dispose(bool disposing)
    {
        if (disposing)
        {
            ctx.Dispose();
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
    #endregion IDisposable

    #region IAsyncDisposable
    private async ValueTask DisposeAsyncCore()
    {
        await ctx.DisposeAsync();
    }

    public async ValueTask DisposeAsync()
    {
        await DisposeAsyncCore();
        GC.SuppressFinalize(this);
    }
    #endregion IAsyncDisposable

}
