﻿using DataObj = Access.Numbers.Orm.Models;
using AccessObj = Access.Numbers.Contract.Models;

namespace Access.Numbers.Service.Helpers;

public class MappingProfile : Profile
{

    public MappingProfile()
    {

        #region FactorialNumber
        CreateMap<DataObj.FactorialNumber, AccessObj.FactorialNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));

        CreateMap<AccessObj.FactorialNumber, DataObj.FactorialNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion FactorialNumber

        #region FibonacciNumber
        CreateMap<DataObj.FibonacciNumber, AccessObj.FibonacciNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        
        CreateMap<AccessObj.FibonacciNumber, DataObj.FibonacciNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion FibonacciNumber

        #region PerfectNumber
        CreateMap<DataObj.PerfectNumber, AccessObj.PerfectNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        
        CreateMap<AccessObj.PerfectNumber, DataObj.PerfectNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion PerfectNumber

        #region PrimeNumber
        CreateMap<DataObj.PrimeNumber, AccessObj.PrimeNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        
        CreateMap<AccessObj.PrimeNumber, DataObj.PrimeNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion PrimeNumber

        #region SquareNumber
        CreateMap<DataObj.SquareNumber, AccessObj.SquareNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        
        CreateMap<AccessObj.SquareNumber, DataObj.SquareNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion SquareNumber

        #region TriangularNumber
        CreateMap<DataObj.TriangularNumber, AccessObj.TriangularNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        
        CreateMap<AccessObj.TriangularNumber, DataObj.TriangularNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion TriangularNumber

    }

}