// Global using directives

global using AutoMapper;