﻿namespace Util.Messaging;

public interface IServiceMessageBase
{
    Guid MessageId { get; set; }
    Guid CorrelationId { get; set; }
    DateTime Timestamp { get; set; }
}