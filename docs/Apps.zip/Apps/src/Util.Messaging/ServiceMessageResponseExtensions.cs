﻿namespace Util.Messaging;

public static class ServiceMessageResponseExtensions
{

    public static void AddError(this ServiceMessageResponse response, string message)
    {

        response.ErrorMessages.Add(new ErrorMessage { Message = message });

    }

    public static void AddErrorRange(this ServiceMessageResponse response, ICollection<string> errors)
    {

        foreach (var error in errors)
        {
            response.ErrorMessages.Add(new ErrorMessage { Message = error });
        }

    }

}