﻿namespace Util.Messaging;

public record ErrorMessage
{
    public string Message { get; set; } = string.Empty;
}