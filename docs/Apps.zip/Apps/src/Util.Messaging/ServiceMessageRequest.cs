﻿namespace Util.Messaging;

public record ServiceMessageRequest : ServiceMessageBase, IServiceMessageRequest
{
}