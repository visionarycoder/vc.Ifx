﻿namespace Util.Messaging;

public interface IServiceMessageRequest : IServiceMessageBase
{

}