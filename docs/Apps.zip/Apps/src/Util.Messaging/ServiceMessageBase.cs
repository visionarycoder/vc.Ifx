﻿namespace Util.Messaging;

public abstract record ServiceMessageBase : IServiceMessageBase
{

    public Guid MessageId { get; set; } = Guid.NewGuid();
    public Guid CorrelationId { get; set; } = Guid.NewGuid();
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;

}