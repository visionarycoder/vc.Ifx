﻿namespace Util.Messaging;

public static class ErrorMessageExtensions
{

    public static void AddRange(this ICollection<ErrorMessage> errors, ICollection<string> messages)
    {
        foreach (var message in messages)
        {
            errors.Add(new ErrorMessage { Message = message });
        }
        
    }

    public static void AddRange(this ICollection<ErrorMessage> errors, ICollection<ErrorMessage> errorMessages)
    {
        foreach (var errorMessage in errorMessages)
        {
            errors.Add(errorMessage);
        }
    }

}