namespace Util.Messaging;

public static class ServiceMessageFactory
{

    public static T Create<T>() where T : ServiceMessageBase, new()
    {

        return Create<T>(Guid.NewGuid());

    }

    public static T Create<T>(Guid correlationId) where T : ServiceMessageBase, new()
    {

        var result = new T
        {
            MessageId = Guid.NewGuid(),
            CorrelationId = correlationId,
            Timestamp = DateTime.UtcNow
        };
        return result;

    }

    public static T CreateFrom<T>(ServiceMessageBase message) where T : ServiceMessageBase, new()
    {

        var result = new T
        {
            MessageId = Guid.NewGuid(),
            CorrelationId = message.CorrelationId,
            Timestamp = DateTime.UtcNow
        };
        return result;

    }

    public static async Task<T> CreateAsync<T>() where T : ServiceMessageBase, new()
    {
        return await CreateAsync<T>(Guid.NewGuid());
    }

    public static async Task<T> CreateAsync<T>(Guid correlationId) where T : ServiceMessageBase, new()
    {
        return await Task.FromResult(Create<T>(correlationId));
    }

    public static async Task<T> CreateFromAsync<T>(ServiceMessageBase message) where T : ServiceMessageBase, new()
    {
        var result = new T
        {
            MessageId = Guid.NewGuid(),
            CorrelationId = message.CorrelationId,
            Timestamp = DateTime.UtcNow
        };
        return await Task.FromResult(result);
    }
}