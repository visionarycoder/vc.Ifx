﻿namespace Util.Messaging;

public interface IServiceMessageResponse
{

    public bool IsSuccess { get; }
    public string Message { get; }
    
    public bool HasErrors { get; }
    public ICollection<ErrorMessage> ErrorMessages { get; }

}