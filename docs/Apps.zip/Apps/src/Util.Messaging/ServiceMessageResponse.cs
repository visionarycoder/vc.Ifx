﻿namespace Util.Messaging;

public record ServiceMessageResponse : ServiceMessageBase, IServiceMessageResponse
{

    public bool IsSuccess { get; set; } = true;
    public string Message { get; set; } = string.Empty;

    public bool HasErrors => ErrorMessages.Count == 0;
    public ICollection<ErrorMessage> ErrorMessages { get; } = new List<ErrorMessage>();

}