﻿using Engine.Calculating.Contract.Models;

namespace Engine.Calculating.Contract;

public interface ICalculatingEngine
{
    Task<FactorialNumber?> CalculateFactorialNumberAsync(int number, CancellationToken cancellationToken);
    Task<IEnumerable<FactorialNumber>> CalculateFactorialNumberSequenceAsync(int position, CancellationToken cancellationToken);

    Task<FibonacciNumber?> CalculateFibonacciNumberAsync(int number, CancellationToken cancellationToken);
    Task<IEnumerable<FibonacciNumber>> CalculateFibonacciNumberSequenceAsync(int position, CancellationToken cancellationToken);

    Task<PerfectNumber?> CalculatePerfectNumberAsync(int number, CancellationToken cancellationToken);
    Task<IEnumerable<PerfectNumber>> CalculatePerfectNumberSequenceAsync(int position, CancellationToken cancellationToken);

    Task<PrimeNumber?> CalculatePrimeNumberAsync(int number, CancellationToken cancellationToken);
    Task<IEnumerable<PrimeNumber>> CalculatePrimeNumberSequenceAsync(int position, CancellationToken cancellationToken);

    Task<SquareNumber?> CalculateSquareNumberAsync(int number, CancellationToken cancellationToken);
    Task<IEnumerable<SquareNumber>> CalculateSquareNumberSequenceAsync(int position, CancellationToken cancellationToken);

    Task<TriangularNumber?> CalculateTriangularNumberAsync(int number, CancellationToken cancellationToken);
    Task<IEnumerable<TriangularNumber>> CalculateTriangularNumberSequenceAsync(int position, CancellationToken cancellationToken);
}
