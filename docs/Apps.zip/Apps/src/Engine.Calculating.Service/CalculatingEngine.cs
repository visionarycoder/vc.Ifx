﻿using Access.Numbers.Contract;
using AutoMapper;
using Engine.Calculating.Contract;
using Engine.Calculating.Contract.Models;
using Engine.Calculating.Service.Calculators;
using Engine.Calculating.Service.Helpers;
using Ifx;
using Ifx.Base;
using Microsoft.Extensions.Logging;
#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously

namespace Engine.Calculating.Service;

public class CalculatingEngine(ILogger<CalculatingEngine> logger, INumbersAccess numbersAccess, IMapper? mapper = null) : ServiceBase<CalculatingEngine>(logger), ICalculatingEngine
{

    private readonly IMapper mapper = mapper ?? new MapperConfiguration(cfg => cfg.AddProfile<MappingProfile>()).CreateMapper();

    public async Task<FactorialNumber?> CalculateFactorialNumberAsync(int number, CancellationToken cancellationToken = default)
    {

        var filter = new Filter<Access.Numbers.Contract.Models.FactorialNumber>()
        {
            IgnoreCase = IgnoreCase.Yes,
            Skip = 0,
            Take = 1,
        };
        filter.AddProperty(nameof(FactorialNumber.Position), number);

        var dbObj = (await numbersAccess.FindFactorialNumbersAsync(filter, cancellationToken)).FirstOrDefault();
        if (dbObj != null)
        {
            return mapper.Map<FactorialNumber>(dbObj);
        }

        filter.Skip = null;
        filter.Take = null;

        var calculator = new FactorialCalculator();

        dbObj = await numbersAccess.FindLargestFactorialNumberAsync(cancellationToken);
        var entry = new Access.Numbers.Contract.Models.FactorialNumber();

        var startAt = dbObj is null ? 1 : dbObj.Position + 1;
        foreach (var i in Enumerable.Range(startAt, number))
        {
            var value = calculator.Calculate(i);
            entry = new Access.Numbers.Contract.Models.FactorialNumber
            {
                Position = i,
                Value = value,
            };
            await numbersAccess.AddFactorialNumberAsync(entry, cancellationToken);
        }
        return mapper.Map<FactorialNumber>(entry);

    }

    public async Task<IEnumerable<FactorialNumber>> CalculateFactorialNumberSequenceAsync(int position, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }

    public async Task<IEnumerable<FactorialNumber>> CalculateFactorialNumbersAsync(int start, int end, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<FibonacciNumber?> CalculateFibonacciNumberAsync(int number, CancellationToken cancellationToken = default)
    {

        var filterArg = new KeyValuePair<string, object?>(nameof(FibonacciNumber.Position), number);
        var filter = new Filter<Access.Numbers.Contract.Models.FibonacciNumber>(filterArg)
        {
            IgnoreCase = IgnoreCase.Yes,
            Skip = 0,
            Take = 1,
        };

        var dbObj = (await numbersAccess.FindFibonacciNumbersAsync(filter, cancellationToken)).FirstOrDefault();
        if (dbObj != null)
        {
            return mapper.Map<FibonacciNumber>(dbObj);
        }

        filter.Skip = null;
        filter.Take = null;

        var calculator = new FibonacciCalculator();
        var existing = (await numbersAccess.FindFibonacciNumbersAsync(filter, cancellationToken)).ToList();
        var calculated = calculator
            .Calculate(number, existing.Select(n => n.Value).ToList())
            .ToList();

        var entry = new Access.Numbers.Contract.Models.FibonacciNumber();
        foreach (var value in calculated)
        {

            if (existing.Any(n => n.Value == value))
            {
                continue;
            }
            
            entry = new Access.Numbers.Contract.Models.FibonacciNumber
            {
                Position = existing.Count + 1,
                Value = value,
            };
            
            await numbersAccess.AddFibonacciNumberAsync(entry, cancellationToken);
            existing.Add(entry);

        }

        return mapper.Map<FibonacciNumber>(entry);

    }

    public async Task<IEnumerable<FibonacciNumber>> CalculateFibonacciNumbersAsync(int start, int end, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }

    public async Task<IEnumerable<FibonacciNumber>> CalculateFibonacciNumberSequenceAsync(int position, CancellationToken cancellationToken = default)
    {
        var response = new List<FibonacciNumber>();
        var filterArg = new KeyValuePair<string, object?>(nameof(FibonacciNumber.Position), position);
        var filter = new Filter<Access.Numbers.Contract.Models.FibonacciNumber>(filterArg)
        {
            IgnoreCase = IgnoreCase.Yes,
            Skip = null,
            Take = null,
        };

        var dbObj = await numbersAccess.FindFibonacciNumbersAsync(filter, cancellationToken);
        if (dbObj.Count == 0)
        {
            response.AddRange(dbObj.Select(mapper.Map<FibonacciNumber>));
            return response;
        }

        var calculator = new FibonacciCalculator();
        var existing = (await numbersAccess.FindFibonacciNumbersAsync(filter, cancellationToken)).ToList();
        var calculated = calculator
            .Calculate(position, existing.Select(n => n.Value).ToList())
            .ToList();

        foreach (var value in calculated.Where(value => existing.All(n => n.Value != value)))
        {
            var entry = new Access.Numbers.Contract.Models.FibonacciNumber
            {
                Position = existing.Count + 1,
                Value = value,
            };
            await numbersAccess.AddFibonacciNumberAsync(entry, cancellationToken);
            response.Add(mapper.Map<FibonacciNumber>(entry));
        }
        return response;
    }

    public async Task<PerfectNumber?> CalculatePerfectNumberAsync(int number, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<IEnumerable<PerfectNumber>> CalculatePerfectNumberSequenceAsync(int position, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }

    public async Task<IEnumerable<PerfectNumber>> CalculatePerfectNumbersAsync(int start, int end, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<PrimeNumber?> CalculatePrimeNumberAsync(int number, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<IEnumerable<PrimeNumber>> CalculatePrimeNumberSequenceAsync(int position, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }

    public async Task<IEnumerable<PrimeNumber>> CalculatePrimeNumbersAsync(int start, int end, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<SquareNumber?> CalculateSquareNumberAsync(int number, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<IEnumerable<SquareNumber>> CalculateSquareNumberSequenceAsync(int position, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }

    public async Task<IEnumerable<SquareNumber>> CalculateSquareNumbersAsync(int start, int end, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<TriangularNumber?> CalculateTriangularNumberAsync(int number, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<IEnumerable<TriangularNumber>> CalculateTriangularNumberSequenceAsync(int position, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }

    public async Task<IEnumerable<TriangularNumber>> CalculateTriangularNumbersAsync(int start, int end, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

}