namespace Engine.Calculating.Service.Calculators;

public class FactorialCalculator : IValueCalculator<int, long>
{

    public long Calculate(int n)
    {

        if (n < 0)
        {
            throw new ArgumentException("Input must be a non-negative integer.");
        }

        long result = 1;
        for (long i = 1; i <= n; i++)
        {
            result *= i;
        }
        return result;

    }

}