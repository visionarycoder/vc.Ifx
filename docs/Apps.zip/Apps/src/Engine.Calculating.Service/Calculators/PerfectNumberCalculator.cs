// ReSharper disable MemberCanBePrivate.Global
namespace Engine.Calculating.Service.Calculators;

public class PerfectNumberCalculator : ISequenceCalculator<int, int>
{

    public IEnumerable<int> Calculate(int limit)
    {
        return Enumerable.Range(2, limit).Where(IsPerfectNumber).ToList();
    }

    public IEnumerable<int> Calculate(int count, ICollection<int> existing)
    {
        return Calculate(count);
    }

    /// <summary>
    /// A perfect number is a positive integer that is equal to the sum of its proper divisors (excluding itself). For example:
    /// 6 is a perfect number because 1 + 2 + 3 = 6
    /// 28 is a perfect number because 1 + 2 + 4 + 7 + 14 = 28
    /// </summary>
    /// <param name="number"></param>
    /// <returns></returns>
    public static bool IsPerfectNumber(int number)
    {
        return Enumerable.Range(1, number).Where(i => number % i == 0).Sum() == number;
    }

}