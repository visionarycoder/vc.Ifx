namespace Engine.Calculating.Service.Calculators.Contracts;

public interface ISequenceCalculator<in TIn, TOut>
{
    IEnumerable<TOut> Calculate(TIn count);
    IEnumerable<TOut> Calculate(TIn count, ICollection<TOut> existing);
}