namespace Engine.Calculating.Service.Calculators.Contracts;

public interface IValueCalculator<in TIn, out TOut>
{
    TOut Calculate(TIn n);
}