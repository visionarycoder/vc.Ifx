// ReSharper disable UnusedType.Global
namespace Engine.Calculating.Service.Calculators;

public class PrimeCalculator : ISequenceCalculator<int,int>
{
    
    public IEnumerable<int> Calculate(int n)
    {

        var sieve = Enumerable.Repeat(true, n + 1).ToArray();
        sieve[0] = false;
        sieve[1] = false;

        foreach(var i in Enumerable.Range(2, (int)Math.Sqrt(n) - 1))
        {
            if (!sieve[i])
            {
                continue;
            }
            foreach (var j in Enumerable.Range(i * i, n - i * i + 1).Where(x => x % i == 0))
            {
                sieve[j] = false;
            }
        }
        return sieve.Select((x, i) => new { x, i }).Where(x => x.x).Select(x => x.i);

    }

    public IEnumerable<int> Calculate(int count, ICollection<int> existing)
    {
        return Calculate(count);
    }
}