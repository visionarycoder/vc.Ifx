namespace Engine.Calculating.Service.Calculators;

public class TriangularNumberCalculator : ISequenceCalculator<int, int>
{

    public IEnumerable<int> Calculate(int count)
    {
        var triNumbers = new List<int>();
        for (int i = 1; i <= count; i++)
        {
            triNumbers.Add(i * (i + 1) / 2);
        }
        return triNumbers;
    }

    public IEnumerable<int> Calculate(int count, ICollection<int> existing)
    {
        throw new NotImplementedException();
    }
}