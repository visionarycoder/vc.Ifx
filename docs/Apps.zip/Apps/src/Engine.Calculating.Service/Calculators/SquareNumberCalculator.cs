namespace Engine.Calculating.Service.Calculators;

public class SquareNumberCalculator : ISequenceCalculator<int, int>
{
    public IEnumerable<int> Calculate(int count)
    {
        var sqNumbers = new List<int>();
        for (int i = 1; i <= count; i++)
        {
            sqNumbers.Add(i * i);
        }
        return sqNumbers;
    }

    public IEnumerable<int> Calculate(int count, ICollection<int> existing)
    {
        throw new NotImplementedException();
    }
}