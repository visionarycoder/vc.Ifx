namespace Engine.Calculating.Service.Calculators;

public class FibonacciCalculator : ISequenceCalculator<int, long>
{

    public IEnumerable<long> Calculate(int count)
    {
       return Calculate(count, new List<long> { 0, 1 });
    }

    public IEnumerable<long> Calculate(int count, ICollection<long> existing)
    {
        var sequence = new List<long>(existing);
        var countToCalculate = count - sequence.Count;
        foreach (var i in Enumerable.Range(sequence.Count, countToCalculate))
        {
            sequence.Add(sequence[i - 1] + sequence[i - 2]);
        }
        return sequence;
    }

}