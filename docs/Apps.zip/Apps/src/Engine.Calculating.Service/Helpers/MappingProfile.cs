﻿using AutoMapper;
using EngineObj = Engine.Calculating.Contract.Models;
using AccessObj = Access.Numbers.Contract.Models;

namespace Engine.Calculating.Service.Helpers;

public class MappingProfile : Profile
{

    public MappingProfile()
    {

        #region FactorialNumber
        CreateMap<EngineObj.FactorialNumber, AccessObj.FactorialNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));

        CreateMap<AccessObj.FactorialNumber, EngineObj.FactorialNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion FactorialNumber

        #region FibonacciNumber
        CreateMap<EngineObj.FibonacciNumber, AccessObj.FibonacciNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        
        CreateMap<AccessObj.FibonacciNumber, EngineObj.FibonacciNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion FibonacciNumber

        #region PerfectNumber
        CreateMap<EngineObj.PerfectNumber, AccessObj.PerfectNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        
        CreateMap<AccessObj.PerfectNumber, EngineObj.PerfectNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion PerfectNumber

        #region PrimeNumber
        CreateMap<EngineObj.PrimeNumber, AccessObj.PrimeNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        
        CreateMap<AccessObj.PrimeNumber, EngineObj.PrimeNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion PrimeNumber

        #region SquareNumber
        CreateMap<EngineObj.SquareNumber, AccessObj.SquareNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        
        CreateMap<AccessObj.SquareNumber, EngineObj.SquareNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion SuareNumber

        #region TriangularNumber
        CreateMap<EngineObj.TriangularNumber, AccessObj.TriangularNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        
        CreateMap<AccessObj.TriangularNumber, EngineObj.TriangularNumber>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Position, opt => opt.MapFrom(src => src.Position))
            .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.Value));
        #endregion TriangularNumber

    }

}
