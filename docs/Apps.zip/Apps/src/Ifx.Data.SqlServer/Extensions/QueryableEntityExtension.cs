using Ifx.Extensions;

// ReSharper disable MemberCanBePrivate.Global

namespace Ifx.Data.Extensions;

public static class QueryableEntityExtension
{

	/// <summary>  
	/// Applies the specified filter to the query, including property value filtering, order filtering, and pagination filtering.  
	/// </summary>  
	/// <typeparam name="T">The type of the entities in the query.</typeparam>  
	/// <param name="query">The query to apply the filter to.</param>  
	/// <param name="filter">The filter containing the criteria to apply.</param>  
	/// <returns>The filtered query.</returns>  
	public static IQueryable<T> ApplyFilter<T>(this IQueryable<T> query, Filter<T> filter) where T : Entity
	{

		query = query.ApplyPropertyFilters(filter);
		query = query.ApplyOrdering(filter.OrderBy, filter.OrderByDirection, filter.ThenBy, filter.ThenByDirection);
		query = query.ApplyPagination(filter.Skip, filter.Take);
		return query;

	}

  
	/// <summary>  
	/// Applies property value filtering to the query based on the specified filter.  
	/// </summary>  
	/// <typeparam name="T">The type of the entities in the query.</typeparam>  
	/// <param name="query">The query to apply the filter to.</param>  
	/// <param name="filter">The filter containing property values to filter by.</param>  
	/// <param name="caseInsensitive">Indicates whether the filtering should be case-insensitive.</param>  
	/// <returns>The filtered query.</returns>  
	public static IQueryable<T> ApplyPropertyFilters<T>(this IQueryable<T> query, Filter<T> filter, bool caseInsensitive = true) where T : Entity
	{

		if (filter.FilterValues.Count <= 0)
		{
			return query;
		}

		return filter.FilterValues.Aggregate(query, (current, kvp) => caseInsensitive
			? current.Where(e => EF.Functions.Like(EF.Property<string>(e, kvp.Key), kvp.Value != null ? kvp.Value.ToString() : ""))
			: current.Where(e => EF.Property<object>(e, kvp.Key) == kvp.Value));

	}
    
}