using Microsoft.Extensions.DependencyInjection;

namespace Ifx.Data.Extensions;

public static class DbContextExtension
{

    public static async Task EnsureDbCreatedAsync<TContext>(this IServiceProvider serviceProvider) where TContext : DbContext
    {

        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<TContext>();
        await context.Database.EnsureCreatedAsync().ConfigureAwait(false);

    }

    public static async Task EnsureDbDeletedAsync<TContext>(this IServiceProvider serviceProvider, ForceDatabaseDelete forceDatabaseDelete = ForceDatabaseDelete.No) where TContext : DbContext
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<TContext>();
        var migrations = await context.Database.GetPendingMigrationsAsync().ConfigureAwait(false);
        var shouldDelete = migrations.Any() || forceDatabaseDelete == ForceDatabaseDelete.Yes;
        if (shouldDelete)
        {
            await context.Database.EnsureDeletedAsync().ConfigureAwait(false);
        }
    }

    public static async Task RebuildDatabaseAsync<TContext>(this IServiceProvider serviceProvider, ForceDatabaseDelete forceDatabaseDelete = ForceDatabaseDelete.No) where TContext : DbContext
    {
        await serviceProvider.EnsureDbDeletedAsync<TContext>(forceDatabaseDelete).ConfigureAwait(false);
        await serviceProvider.EnsureDbCreatedAsync<TContext>().ConfigureAwait(false);
    }

    public enum ForceDatabaseDelete
    {
        No,
        Yes
    }


}