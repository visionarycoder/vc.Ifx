using System.Diagnostics;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Logging;

// ReSharper disable MemberCanBePrivate.Global

namespace Ifx.Data.Helper;

public class DbHelper(ILogger logger, DbContext ctx)
{

    private static readonly Action<ILogger, Exception?> LogTimeoutError = LoggerMessage.Define(LogLevel.Error, new EventId(1, nameof(LogTimeoutError)), "A timeout occurred while processing the request.");
    private static readonly Action<ILogger, Exception?> LogGeneralError = LoggerMessage.Define(LogLevel.Error, new EventId(2, nameof(LogGeneralError)), "An error occurred while processing the request.");
    private static readonly Action<ILogger, string, Exception?> LogMethodCalled = LoggerMessage.Define<string>(LogLevel.Information, new EventId(3, nameof(LogMethodCalled)), "{MethodName} method called.");
    private static readonly Action<ILogger, bool, Exception?> LogDatabaseConnectionStatus = LoggerMessage.Define<bool>(LogLevel.Information, new EventId(4, nameof(LogDatabaseConnectionStatus)), "Database connection status: {Status}");
    private static readonly Action<ILogger, bool, Exception?> LogMigrationRequired = LoggerMessage.Define<bool>(LogLevel.Information, new EventId(5, nameof(LogMigrationRequired)), "Migration required: {Status}");
    private static readonly Action<ILogger, int, Exception?> LogEntityCount = LoggerMessage.Define<int>(LogLevel.Information, new EventId(6, nameof(LogEntityCount)), "Entity count: {Count}");
    private static readonly Action<ILogger, string, Exception?> LogDatabaseRebuilt = LoggerMessage.Define<string>(LogLevel.Information, new EventId(7, nameof(LogDatabaseRebuilt)), "Database rebuilt successfully in {MethodName}.");

    public int ExtendedTimeout { get; set; } = 120;
    public int DefaultTimeout { get; } = ctx.Database.GetCommandTimeout() ?? 30;

    public async Task<bool> CanConnectAsync()
    {
        LogMethodCalled(logger, nameof(CanConnectAsync), null);
        try
        {
            var canConnect = await ctx.Database.CanConnectAsync().ConfigureAwait(false);
            LogDatabaseConnectionStatus(logger, canConnect, null);
            return canConnect;
        }
        catch (DbUpdateException ex) when (ex.InnerException is SqlException { Number: -2 })
        {
            LogTimeoutError(logger, ex);
            Debug.WriteLine(ex);
            return false;
        }
        catch (Exception ex)
        {
            LogGeneralError(logger, ex);
            Debug.WriteLine(ex);
            return false;
        }
    }

    public async Task<bool> RebuildDatabaseAsync()
    {
        LogMethodCalled(logger, nameof(RebuildDatabaseAsync), null);
        try
        {
            ctx.Database.SetCommandTimeout(ExtendedTimeout);
            await ctx.Database.EnsureDeletedAsync().ConfigureAwait(false);
            await ctx.Database.EnsureCreatedAsync().ConfigureAwait(false);
            ctx.Database.SetCommandTimeout(DefaultTimeout);
            LogDatabaseRebuilt(logger, nameof(RebuildDatabaseAsync), null);
            return true;
        }
        catch (DbUpdateException ex) when (ex.InnerException is SqlException { Number: -2 })
        {
            LogTimeoutError(logger, ex);
            Debug.WriteLine(ex);
            return false;
        }
        catch (Exception ex)
        {
            LogGeneralError(logger, ex);
            Debug.WriteLine(ex);
            return false;
        }
    }

    public async Task<bool> IsMigrationRequiredAsync()
    {
        LogMethodCalled(logger, nameof(IsMigrationRequiredAsync), null);
        try
        {
            var hasChanges = ctx.Database.HasPendingModelChanges();
            LogMigrationRequired(logger, hasChanges, null);
            return hasChanges;
        }
        catch (DbUpdateException ex) when (ex.InnerException is SqlException { Number: -2 })
        {
            LogTimeoutError(logger, ex);
            Debug.WriteLine(ex);
            return await Task.FromResult(false).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            LogGeneralError(logger, ex);
            Debug.WriteLine(ex);
            return await Task.FromResult(false).ConfigureAwait(false);
        }
    }

    public async Task<ICollection<IEntityType>> GetEntitiesAsync()
    {
        LogMethodCalled(logger, nameof(GetEntitiesAsync), null);
        try
        {
            ctx.Database.SetCommandTimeout(ExtendedTimeout);
            var entityTypes = ctx.Model.GetEntityTypes().ToList();
            ctx.Database.SetCommandTimeout(DefaultTimeout);
            LogEntityCount(logger, entityTypes.Count, null);
            return entityTypes;
        }
        catch (DbUpdateException ex) when (ex.InnerException is SqlException { Number: -2 })
        {
            LogTimeoutError(logger, ex);
            Debug.WriteLine(ex);
            return await Task.FromResult(new List<IEntityType>()).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            LogGeneralError(logger, ex);
            Debug.WriteLine(ex);
            return await Task.FromResult(new List<IEntityType>()).ConfigureAwait(false);
        }
    }

    public async Task<int> GetEntityCountAsync()
    {
        LogMethodCalled(logger, nameof(GetEntityCountAsync), null);
        try
        {
            var count = ctx
                .Model
                .GetEntityTypes()
                .Count();
            LogEntityCount(logger, count, null);
            return count;
        }
        catch (DbUpdateException ex) when (ex.InnerException is SqlException { Number: -2 })
        {
            LogTimeoutError(logger, ex);
            Debug.WriteLine(ex);
            return await Task.FromResult(-1).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            LogGeneralError(logger, ex);
            Debug.WriteLine(ex);
            return await Task.FromResult(-1).ConfigureAwait(false);
        }
    }

    public string GetConnectionString()
    {
        return ctx.Database.GetConnectionString() ?? throw new InvalidOperationException();
    }

}