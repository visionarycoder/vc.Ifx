﻿// ReSharper disable MemberCanBePrivate.Global

global using Microsoft.EntityFrameworkCore;