﻿namespace Access.Rules.Contract;

public interface IRulesAccess
{

    Task<string> GetWorkflowAsync(string workflowName);

}