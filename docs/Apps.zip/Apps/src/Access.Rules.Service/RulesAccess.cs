﻿namespace Access.Rules.Service;

public class RulesAccess(ILogger<RulesAccess> logger, DbContextOptions<RulesContext> options) : ServiceBase<RulesAccess>(logger), IRulesAccess, IDisposable, IAsyncDisposable
{

    private readonly RulesContext ctx = new(options);
    
    public async Task<string> GetWorkflowAsync(string workflowName)
    {
        
        var workflow = await ctx.WorkflowEntries.SingleOrDefaultAsync(i => i.WorkflowName == workflowName);
        return workflow == null
            ? string.Empty
            : workflow.Json;

    }
    
    #region IDisposable
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    private void Dispose(bool disposing)
    {
        if (disposing)
        {
            ctx.Dispose();
        }
    }

    public async ValueTask DisposeAsync()
    {
        await DisposeAsyncCore();
        GC.SuppressFinalize(this);
    }

    private async ValueTask DisposeAsyncCore()
    {
        await ctx.DisposeAsync();
    }

    ~RulesAccess()
    {
        Dispose(false);
    }
    #endregion

}