// Global using directives

global using Access.Rules.Contract;
global using Access.Rules.Orm;
global using Ifx.Base;
global using Microsoft.EntityFrameworkCore;
global using Microsoft.Extensions.Logging;

// Enable visibility of internal members to the unit test project
// This has to follow the global using directives
using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Access.Rules.Service.UnitTests")]
