﻿namespace Ifx.Messaging;

/// <summary>
/// Common interfaces for all request service messages.
/// </summary>
public interface IServiceMessageRequest : IServiceMessage
{
}