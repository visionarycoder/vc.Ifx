﻿namespace Ifx.Messaging;

/// <summary>
/// Abstract base class for all request service messages.
/// </summary>
public abstract class ServiceMessageRequest : ServiceMessage, IServiceMessageRequest
{

}