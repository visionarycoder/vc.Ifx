﻿using Ifx;
using Ifx.Messaging;

using Manager.Content.Contract.Models;

namespace Manager.Content.Contract;

public interface IContentManager
{

    Task<GetFactorialNumberResponse> GetFactorialNumberAsync(GetFactorialNumberRequest request, CancellationToken cancellationToken);
    Task<GetFactorialNumberSequenceResponse> GetFactorialNumberSequenceAsync(GetFactorialNumberSequenceRequest request, CancellationToken cancellationToken);

    Task<GetFibonacciNumberResponse> GetFibonacciNumberAsync(GetFibonacciNumberRequest request, CancellationToken cancellationToken);
    Task<GetFibonacciNumberSequenceResponse> GetFibonacciNumberSequenceAsync(GetFibonacciNumberSequenceRequest request, CancellationToken cancellationToken);

    Task<GetPerfectNumberResponse> GetPerfectNumberAsync(GetPerfectNumberRequest request, CancellationToken cancellationToken);
    Task<GetPerfectNumberSequenceResponse> GetPerfectNumberSequenceAsync(GetPerfectNumberSequenceRequest request, CancellationToken cancellationToken);

    Task<GetPrimeNumberResponse> GetPrimeNumberAsync(GetPrimeNumberRequest request, CancellationToken cancellationToken);
    Task<GetPrimeNumberSequenceResponse> GetPrimeNumberSequenceAsync(GetPrimeNumberSequenceRequest request, CancellationToken cancellationToken);

    Task<GetSquareNumberResponse> GetSquareNumberAsync(GetSquareNumberRequest request, CancellationToken cancellationToken);
    Task<GetSquareNumberSequenceResponse> GetSquareNumberSequenceAsync(GetSquareNumberSequenceRequest request, CancellationToken cancellationToken);

    Task<GetTriangularNumberResponse> GetTriangularNumberAsync(GetTriangularNumberRequest request, CancellationToken cancellationToken);
    Task<GetTriangularNumberSequenceResponse> GetTriangularNumberSequenceAsync(GetTriangularNumberSequenceRequest request, CancellationToken cancellationToken);

}

public abstract class GetNumberRequest<T> : ServiceMessageRequest where T : class, new()
{
    public required Filter<T> Filter { get; set; }
}

public abstract class GetNumberResponse<T> : ServiceMessageResponse where T : class, new()
{
    public T? Number { get; set; }
}

public abstract class GeNumberCollectionResponse<T> : ServiceMessageRequest where T : class, new()
{
    public ICollection<T> Collection { get; set; } = new List<T>();
}

#region FactorialNumber
public class GetFactorialNumberRequest : GetNumberRequest<FactorialNumber> { }
public class GetFactorialNumberResponse : GetNumberResponse<FactorialNumber> { }
public class GetFactorialNumberSequenceRequest : GetNumberRequest<FactorialNumber> { }
public class GetFactorialNumberSequenceResponse : GeNumberCollectionResponse<FactorialNumber> { }
#endregion

#region FibonacciNumber
public class GetFibonacciNumberRequest : GetNumberRequest<FibonacciNumber> { }
public class GetFibonacciNumberResponse : GetNumberResponse<FibonacciNumber> { }
public class GetFibonacciNumberSequenceRequest : GetNumberRequest<FibonacciNumber> { }
public class GetFibonacciNumberSequenceResponse : GeNumberCollectionResponse<FibonacciNumber> { }
#endregion

#region PerfectNumber
public class GetPerfectNumberRequest : GetNumberRequest<PerfectNumber> { }
public class GetPerfectNumberResponse : GetNumberResponse<PerfectNumber> { }
public class GetPerfectNumberSequenceRequest : GetNumberRequest<PerfectNumber> { }
public class GetPerfectNumberSequenceResponse : GeNumberCollectionResponse<PerfectNumber> { }
#endregion

#region PrimeNumber
public class GetPrimeNumberRequest : GetNumberRequest<PrimeNumber> { }
public class GetPrimeNumberResponse : GetNumberResponse<PrimeNumber> { }
public class GetPrimeNumberSequenceRequest : GetNumberRequest<PrimeNumber> { }
public class GetPrimeNumberSequenceResponse : GeNumberCollectionResponse<PrimeNumber> { }
#endregion

#region SquareNumber
public class GetSquareNumberRequest : GetNumberRequest<SquareNumber> { }
public class GetSquareNumberResponse : GetNumberResponse<SquareNumber> { }
public class GetSquareNumberSequenceRequest : GetNumberRequest<SquareNumber> { }
public class GetSquareNumberSequenceResponse : GeNumberCollectionResponse<SquareNumber> { }
#endregion

#region TriangularNumber
public class GetTriangularNumberRequest : GetNumberRequest<TriangularNumber> { }
public class GetTriangularNumberResponse : GetNumberResponse<TriangularNumber> { }
public class GetTriangularNumberSequenceRequest : GetNumberRequest<TriangularNumber> { }
public class GetTriangularNumberSequenceResponse : GeNumberCollectionResponse<TriangularNumber> { }
#endregion
