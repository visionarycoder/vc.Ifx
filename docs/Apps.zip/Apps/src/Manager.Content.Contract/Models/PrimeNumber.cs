namespace Manager.Content.Contract.Models;

public class PrimeNumber : DtoBase
{
    public int Position { get; set; }
    public long Value { get; set; }
}