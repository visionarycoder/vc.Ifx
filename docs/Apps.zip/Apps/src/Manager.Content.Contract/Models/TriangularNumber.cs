namespace Manager.Content.Contract.Models;

public class TriangularNumber : DtoBase
{
    public int Position { get; set; }
    public long Value { get; set; }
}