﻿namespace Ifx.Cli;

public static class ConsoleHelper
{
    public static FileInfo? PromptForInputFile()
    {
        while (true)
        {
            Console.WriteLine($"Please enter the path to your file (or type 'exit' to quit):");
            var path = Console.ReadLine()!.ToLower(CultureInfo.InvariantCulture);

            if (string.IsNullOrEmpty(path))
            {
                Console.WriteLine("File path cannot be empty.");
                continue;
            }

            if (string.Equals(path, "exit", StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }

            var fileInfo = new FileInfo(path);
            if (fileInfo.Exists)
            {
                return fileInfo;
            }
            Console.WriteLine("File does not exist.");
        }
    }

    public static DirectoryInfo? PromptForInputFolder()
    {
        while (true)
        {
            Console.WriteLine("Please enter the path to the folder (or type 'exit' to quit):");
            var path = Console.ReadLine()!.ToLower(CultureInfo.InvariantCulture);

            if (string.IsNullOrEmpty(path))
            {
                Console.WriteLine("Folder path cannot be empty.");
                continue;
            }

            if (string.Equals(path, "exit", StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }

            var dirInfo = new DirectoryInfo(path);
            if (dirInfo.Exists)
            {
                return dirInfo;
            }
            Console.WriteLine("Folder does not exist.");
        }
    }

    public static int PromptForMenuSelection(string[] options)
    {
        while (true)
        {
            Console.WriteLine("Select an option:");
            for (int i = 0; i < options.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {options[i]}");
            }
            Console.WriteLine("0. Exit");

            var choice = Console.ReadLine();
            if (int.TryParse(choice, out int selectedOption) && selectedOption >= 0 && selectedOption <= options.Length)
            {
                return selectedOption;
            }

            Console.WriteLine("Invalid choice. Please select a valid option.");
        }
    }

    public static int PromptForInt(string promptMessage, string invalidInputMessage)
    {
        while (true)
        {
            Console.Write(promptMessage);
            if (int.TryParse(Console.ReadLine(), out var position))
            {
                return position;
            }
            Console.WriteLine(invalidInputMessage);
        }
    }

}
