﻿// ReSharper disable MemberCanBePrivate.Global

global using System.Globalization;