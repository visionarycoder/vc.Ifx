# Apps

Apps is an example of a  simple system structure with enough content to show a degree of 'work' without too many distractions.

The volatility-based decomposition architecture pattern is expressed.  It may not be perfect a implementation, but it is 'enough' to show how the data moves through the system.  The message is the application.  

The message is the app.

