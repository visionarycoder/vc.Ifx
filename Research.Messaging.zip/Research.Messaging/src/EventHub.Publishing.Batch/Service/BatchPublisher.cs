﻿using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Producer;
using EventHub.Core;
using EventHub.Publishing.Batch.Contract;

namespace EventHub.Publishing.Batch.Service;

public class BatchPublisher : IBatchPublisher
{

    private readonly string publisherName = AssemblyHelper.GetCallingAssemblyName();

    public async Task PublishAsync(int batchSize)
    {

        var producerClient = new EventHubProducerClient(GlobalConstants.PublisherConnectionString, GlobalConstants.EventHubName);
        using var eventBatch = await producerClient.CreateBatchAsync();
        for (var i = 1; i <= batchSize; i++)
        {
            var message = $"Message from {publisherName} ({i} of {batchSize}).";
            var logEntry = ApplicationLogEntryFactory.Create(message);
            var body = logEntry.ToByteArray();
            if (!eventBatch.TryAdd(new EventData(body)))
            {
                Console.WriteLine($"Event {i} is too large for the batch and cannot be sent.");
            }
        }
        await producerClient.SendAsync(eventBatch);
        Console.WriteLine($"Sent {eventBatch.Count} of {batchSize} messages sent.");

    }

}