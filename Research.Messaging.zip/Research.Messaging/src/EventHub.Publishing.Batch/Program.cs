﻿using EventHub;
using EventHub.Core;
using EventHub.Publishing.Batch.Service;
using static EventHub.Core.RuntimeHelper;

var publisherName = AssemblyHelper.GetCallingAssemblyName();

Console.WriteLine($"{publisherName}");
Console.WriteLine("Waiting....");
Sleep();

var rand = new Random();
var pub = new BatchPublisher();

while (true)
{
    
    var batchSize = rand.Next(1, 10);
    await pub.PublishAsync(batchSize);
    Sleep();

}