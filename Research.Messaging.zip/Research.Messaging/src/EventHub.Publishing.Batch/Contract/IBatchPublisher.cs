﻿namespace EventHub.Publishing.Batch.Contract;

public interface IBatchPublisher
{
    Task PublishAsync(int batchSize);
}