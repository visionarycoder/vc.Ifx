﻿namespace EventHub.Publishing.AdHoc.Contract;

public interface IAdHocPublisher
{
    Task PublishAsync();
}