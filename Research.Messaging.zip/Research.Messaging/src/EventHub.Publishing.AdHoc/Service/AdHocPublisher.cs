﻿using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Producer;
using EventHub.Core;
using EventHub.Publishing.AdHoc.Contract;

namespace EventHub.Publishing.AdHoc.Service;

public class AdHocPublisher : IAdHocPublisher
{

    private readonly string publisherName = AssemblyHelper.GetCallingAssemblyName();

    public async Task PublishAsync()
    {
        var message = $"Message from {publisherName}.";
        var logEntry = ApplicationLogEntryFactory.Create(message);
        var eventData = new EventData(logEntry.ToByteArray());
        var publisher = new EventHubProducerClient(GlobalConstants.PublisherConnectionString, GlobalConstants.EventHubName);
        await publisher.SendAsync([eventData]);
        Console.WriteLine("LogEntry sent.");
        await publisher.DisposeAsync();

    }

}