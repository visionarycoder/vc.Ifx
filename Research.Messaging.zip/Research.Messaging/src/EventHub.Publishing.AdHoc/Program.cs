﻿using EventHub;
using EventHub.Core;
using EventHub.Publishing.AdHoc.Service;

var publisherName = AssemblyHelper.GetCallingAssemblyName();
var pub = new AdHocPublisher();

Console.WriteLine($"{publisherName}");
Console.WriteLine("Waiting....");
Thread.Sleep(10 * 1_000);

while (true)
{

    Console.Write("Send LogEntry?  (Y/N)" );
    var key = Console.ReadKey();
    if (key.Key == ConsoleKey.N)
    {
        break;
    }
    Console.WriteLine();

    await pub.PublishAsync();

}

Console.WriteLine("End of the program.");
Console.ReadLine();