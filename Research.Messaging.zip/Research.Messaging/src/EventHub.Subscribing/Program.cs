﻿using EventHub.Subscribing.Service;

var subscriber = new Subscriber();
await subscriber.SubscribeAsync();