﻿using Azure.Messaging.EventHubs.Consumer;
using EventHub.Core;
using EventHub.Subscribing.Contract;

namespace EventHub.Subscribing.Service;

public class Subscriber : ISubscriber
{

    public async Task SubscribeAsync()
    {

        var client = new EventHubConsumerClient(GlobalConstants.EventHubConsumerGroup, GlobalConstants.SubscriberConnectionString, RuntimeVariables.EventHubConsumerClientOptions);
        await foreach (var partitionEvent in client.ReadEventsAsync(CancellationToken.None))
        {
            Console.WriteLine($"Event Read at {DateTime.Now:G}");
            Console.WriteLine(partitionEvent.Data.MessageId);
            var logEntry = ApplicationLogEntryExtensions.FromByteArray(partitionEvent.Data.Body.ToArray());
            Console.WriteLine($"\tMessage: {logEntry.Message} - Timestamp: {logEntry.Timestamp}");
        }

    }

}