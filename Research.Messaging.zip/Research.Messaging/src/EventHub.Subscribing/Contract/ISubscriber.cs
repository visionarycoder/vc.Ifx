﻿namespace EventHub.Subscribing.Contract;

public interface ISubscriber
{
    Task SubscribeAsync();
}