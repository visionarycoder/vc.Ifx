﻿namespace EventHub.Core;

public static class ApplicationLogEntryFactory
{

    public static ApplicationLogEntry Create(string message)
    {
    
        return new ApplicationLogEntry
        {
            Message = message,
            Timestamp = DateTime.UtcNow
        };

    }

}