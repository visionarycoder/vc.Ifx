﻿namespace EventHub.Core;

public static class GlobalConstants
{

    public const string PublisherConnectionString = "Endpoint=sb://evhn-idl-poc.servicebus.windows.net/;SharedAccessKeyName=Publisher;SharedAccessKey=fYLyhVhNJKOs4+qQ3Oaop5fQPy2ypngic+AEhAbDBfQ=;EntityPath=evh-idl-poc";
    public const string SubscriberConnectionString = "Endpoint=sb://evhn-idl-poc.servicebus.windows.net/;SharedAccessKeyName=Subscriber;SharedAccessKey=74nYlnxefwu6KB+7Zo1tBxa0wiXCvSIYl+AEhP/hCYI=;EntityPath=evh-idl-poc";
    public const string ManagerConnectionString = "Endpoint=sb://evhn-idl-poc.servicebus.windows.net/;SharedAccessKeyName=Manager;SharedAccessKey=LX/4vFA9mrs1F7kXmCxvlRPmXQk/pjBkP+AEhABM5m8=;EntityPath=evh-idl-poc";
    public const string EventHubName = "evh-idl-poc";
    public const string EventHubNamespace = "evhn-idl-poc";
    public const string EventHubConsumerGroup = "$Default";


}