﻿namespace EventHub.Core;

public class ApplicationLogEntry
{
    public string Message { get; init; } = "No message set.";
    public DateTime Timestamp { get; init; } = DateTime.MinValue;

    public static ApplicationLogEntry Empty => new ApplicationLogEntry
    {
        Message = "Empty",
        Timestamp = DateTime.MinValue
    };
}