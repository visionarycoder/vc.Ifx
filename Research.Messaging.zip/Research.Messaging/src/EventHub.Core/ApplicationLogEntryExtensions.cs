﻿using System.Text;

namespace EventHub.Core;

public static class ApplicationLogEntryExtensions
{
    public static byte[] ToByteArray(this ApplicationLogEntry source)
    {
        var json = System.Text.Json.JsonSerializer.Serialize(source);
        return Encoding.UTF8.GetBytes(json);
    }

    public static ApplicationLogEntry FromByteArray(byte[] body)
    {
        if (body.Length == 0)
        {
            Console.Error.WriteLine("No elements is body: byte[].");
            return ApplicationLogEntry.Empty;
        }

        var json = Encoding.UTF8.GetString(body);
        if (string.IsNullOrWhiteSpace(json))
        {
            Console.Error.WriteLine("json is empty.");
            return ApplicationLogEntry.Empty;
        }

        try
        {
            return System.Text.Json.JsonSerializer.Deserialize<ApplicationLogEntry>(json) ?? ApplicationLogEntry.Empty;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("Unable to deserialize json.");
            Console.Error.WriteLine($"{ex.Message}");
        }
        return ApplicationLogEntry.Empty;
    }
}