﻿using System.Reflection;
using System.Runtime.CompilerServices;

namespace EventHub.Core;

public static class AssemblyHelper
{

    public static string GetCallingAssemblyName([CallerMemberName] string callingMemberName = "Unknown")
    {
        return Assembly.GetCallingAssembly().GetName().Name ?? callingMemberName;
    }

}