﻿namespace EventHub.Core;

public static class RuntimeHelper
{
        
    public static void Sleep(int seconds = 10) => Thread.Sleep(seconds * 1_000);

}