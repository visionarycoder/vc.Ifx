﻿using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Consumer;

namespace EventHub.Core;

public static class RuntimeVariables
{

    public static EventHubConsumerClientOptions EventHubConsumerClientOptions { get; } = new EventHubConsumerClientOptions
    {
        ConnectionOptions = new EventHubConnectionOptions
        {
            TransportType = EventHubsTransportType.AmqpWebSockets,
        },
        RetryOptions = new EventHubsRetryOptions
        {
            Mode = EventHubsRetryMode.Exponential,
            MaximumRetries = 5,
        }
    };

}